# Pre-configured Demo Test Credentials

> **Notice:** This file contains local development and testing credentials and is ignored by Git (`.gitignore`). Do not commit real production passwords to version control.

---

### 1. Workspace Owner (Customer / Tenant Admin)
- **Role:** Workspace Owner (`owner`)
- **Email:** `owner@qfunnel.local`
- **Password:** `Password123!`
- **Access Level:**
  - Create and publish funnels, calculators, and quote funnels
  - View workspace leads, submissions, and analytics
  - Manage workspace team members and invitations
  - Upgrade subscription plans and manage billing via Cashfree / Stripe / Bank Transfer
  - Configure workspace settings and custom domain

---

### 2. Platform Super Administrator (Master Admin)
- **Role:** Super Administrator (`superadmin`)
- **Email:** `superadmin@qfunnel.local`
- **Password:** `Password123!`
- **Access Level:**
  - Full platform management console (`/admin/platform`)
  - Manage all customer workspaces and tenants (suspend, reactivate, assign plans)
  - Configure subscription plans, limits, and pricing
  - Configure payment gateways (Cashfree, Stripe, PayPal, Razorpay, Bank Transfer)
  - Configure global SMTP server and test email delivery
  - Email Template CMS (customize subjects, HTML templates, reset defaults)
  - Global system audit logs and revenue metrics

---

### 3. Test Signup & Email Verification
- **Test OTP Code:** `123456` (Universal test OTP enabled in local development)
- **Dynamic OTP Banner:** On the verification page (`/verify-email`), the generated code is automatically displayed in the top blue banner with an **Auto Fill** button.

---

### Quick Access URLs
- **Sign In:** `http://localhost:5173/login`
- **Sign Up:** `http://localhost:5173/register`
- **Verify Email:** `http://localhost:5173/verify-email`
- **Billing Management:** `http://localhost:5173/admin/billing`
- **Super Admin Console:** `http://localhost:5173/admin/platform`
