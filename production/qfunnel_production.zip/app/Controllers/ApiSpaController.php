<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\Request;
use App\Core\Response;
use App\Core\Session;
use App\Core\Database;
use App\Core\Env;
use App\Services\AuthService;
use App\Services\TenantContextService;
use App\Services\AuthorizationService;
use App\Services\FunnelService;
use App\Services\FunnelPublishService;
use App\Services\FormSchemaService;
use App\Services\SubmissionService;
use App\Services\LeadStageService;
use App\Services\AnalyticsService;
use App\Services\UsageLimitService;
use App\Services\SubscriptionService;
use App\Services\PlatformSettingService;
use App\Services\AuditLogService;
use App\Services\WebhookService;
use App\Services\LegalPageService;
use App\Services\SupportTicketService;
use App\Services\MailService;
use App\Services\EmailVerificationService;
use App\Services\CashfreeService;
use App\Services\RateLimiterService;
use App\Services\FunnelGraphService;
use App\Services\QuizEngineService;

class ApiSpaController
{
    // ==========================================
    // AUTHENTICATION & SESSION
    // ==========================================

    public function csrfToken(Request $request): Response
    {
        return Response::success([
            'csrf_token' => csrf_token(),
        ]);
    }

    public function login(Request $request): Response
    {
        $email = trim((string)$request->input('email', ''));
        $password = (string)$request->input('password', '');

        $result = AuthService::attempt($email, $password);

        if (!$result['success']) {
            return Response::error($result['error'] ?? 'Invalid credentials.', 'AUTH_FAILED', null, 401);
        }

        $rememberMe = (bool)$request->input('remember_me', false);
        if ($rememberMe) {
            Session::extendLifetime(30 * 86400); // 30 days persistent session
        }

        $user = current_user();
        $tenant = TenantContextService::getActiveTenant();
        $role = TenantContextService::getCurrentRole();
        $userTenants = TenantContextService::getUserTenants((int)$user['id']);

        return Response::success([
            'user' => $user,
            'active_tenant' => $tenant,
            'role' => $role,
            'user_tenants' => $userTenants,
            'csrf_token' => csrf_token(),
        ], "Login successful.");
    }

    public function register(Request $request): Response
    {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        if (!RateLimiterService::check('register', $ip, 5, 3600)) {
            return Response::error("Too many account registrations from this IP address. Please try again after 1 hour.", "RATE_LIMIT_EXCEEDED", null, 429);
        }

        $name = trim((string)$request->input('name', ''));
        $email = trim((string)$request->input('email', ''));
        $password = (string)$request->input('password', '');
        $workspace = trim((string)$request->input('workspace', ''));

        $result = AuthService::register($name, $email, $password, $workspace);

        if (!$result['success']) {
            return Response::error($result['error'] ?? 'Registration failed.', 'REGISTER_FAILED', null, 400);
        }

        // Auto login after registration
        $loginRes = AuthService::attempt($email, $password);
        $user = current_user();
        $tenant = TenantContextService::getActiveTenant();
        $role = TenantContextService::getCurrentRole();
        $userTenants = TenantContextService::getUserTenants((int)$user['id']);

        return Response::success([
            'user' => $user,
            'active_tenant' => $tenant,
            'role' => $role,
            'user_tenants' => $userTenants,
            'csrf_token' => csrf_token(),
            'requires_verification' => empty($user['email_verified_at']),
            'email_verified' => !empty($user['email_verified_at']),
            'expires_in_minutes' => $result['otp_data']['expires_in_minutes'] ?? 15,
        ], "Registration successful. Please verify your email with the 6-digit code.", 201);
    }

    public function verifyOtp(Request $request): Response
    {
        $user = current_user();
        if (!$user) {
            return Response::error("Unauthenticated.", "UNAUTHENTICATED", null, 401);
        }

        $otp = trim((string)$request->input('otp', ''));
        if (empty($otp)) {
            return Response::error("Please enter the 6-digit verification code.", "VALIDATION_FAILED", null, 422);
        }

        $result = EmailVerificationService::verifyOtp((int)$user['id'], $otp);
        if (!$result['success']) {
            return Response::error($result['error'], "VERIFICATION_FAILED", null, 400);
        }

        $freshUser = current_user();
        $tenant = TenantContextService::getActiveTenant();
        $role = TenantContextService::getCurrentRole();
        $userTenants = TenantContextService::getUserTenants((int)$freshUser['id']);

        return Response::success([
            'user' => $freshUser,
            'active_tenant' => $tenant,
            'role' => $role,
            'user_tenants' => $userTenants,
            'email_verified' => true,
        ], $result['message']);
    }

    public function resendOtp(Request $request): Response
    {
        $user = current_user();
        if (!$user) {
            return Response::error("Unauthenticated.", "UNAUTHENTICATED", null, 401);
        }

        $result = EmailVerificationService::resend((int)$user['id']);
        if (!$result['success']) {
            return Response::error($result['error'], "RESEND_FAILED", [
                'retry_after' => $result['retry_after'] ?? null
            ], 429);
        }

        return Response::success([
            'expires_in_minutes' => $result['expires_in_minutes'] ?? 15,
            'simulated' => $result['simulated'] ?? false,
        ], $result['message']);
    }

    public function me(Request $request): Response
    {
        $user = current_user();
        if (!$user) {
            return Response::error("Unauthenticated.", "UNAUTHENTICATED", null, 401);
        }

        // Keep user fresh in session with avatar_url
        $freshUser = Database::fetchOne("SELECT id, name, email, avatar_url, is_platform_admin, status, email_verified_at, created_at FROM users WHERE id = ?", [(int)$user['id']]);
        if ($freshUser) {
            $user = array_merge($user, $freshUser);
            Session::set('user', $user);
        }

        $tenant = TenantContextService::getActiveTenant();
        $role = TenantContextService::getCurrentRole();
        $userTenants = TenantContextService::getUserTenants((int)$user['id']);
        
        $limits = null;
        $features = null;
        if ($tenant) {
            $limits = UsageLimitService::getTenantLimits((int)$tenant['id']);
            $features = UsageLimitService::getTenantFeatures((int)$tenant['id']);
        }

        return Response::success([
            'user' => $user,
            'active_tenant' => $tenant,
            'role' => $role,
            'user_tenants' => $userTenants,
            'limits' => $limits,
            'features' => $features,
            'is_platform_admin' => !empty($user['is_platform_admin']),
            'csrf_token' => csrf_token(),
        ]);
    }

    public function switchWorkspace(Request $request): Response
    {
        $user = current_user();
        if (!$user) {
            return Response::error("Unauthenticated.", "UNAUTHENTICATED", null, 401);
        }

        $tenantId = (int)$request->input('tenant_id');
        $success = TenantContextService::setActiveTenant($tenantId, (int)$user['id']);

        if (!$success) {
            return Response::error("Could not switch to specified workspace.", "FORBIDDEN", null, 403);
        }

        $tenant = TenantContextService::getActiveTenant();
        $role = TenantContextService::getCurrentRole();

        return Response::success([
            'active_tenant' => $tenant,
            'role' => $role,
        ], "Switched workspace successfully.");
    }

    public function logout(Request $request): Response
    {
        Session::destroy();
        Session::start();
        return Response::success(null, "Logged out successfully.");
    }

    // ==========================================
    // DASHBOARD & ANALYTICS
    // ==========================================

    public function dashboard(Request $request): Response
    {
        $tenantId = TenantContextService::getActiveTenantId();
        if (!$tenantId) {
            return Response::error("No active workspace.", "NO_TENANT", null, 400);
        }

        $metrics = AnalyticsService::getDashboardMetrics($tenantId);
        $usage = UsageLimitService::getUsageOverview($tenantId);
        $recentFunnels = FunnelService::listFunnels($tenantId, null, null, 1, 5);

        return Response::success([
            'metrics' => $metrics,
            'usage' => $usage,
            'recent_funnels' => $recentFunnels['items'] ?? ($recentFunnels['data'] ?? (is_array($recentFunnels) ? $recentFunnels : [])),
        ]);
    }

    public function analytics(Request $request): Response
    {
        $tenantId = TenantContextService::getActiveTenantId();
        $funnels = FunnelService::listFunnels($tenantId);
        $funnelList = isset($funnels['items']) ? $funnels['items'] : (isset($funnels['data']) ? $funnels['data'] : (is_array($funnels) ? $funnels : []));
        $selectedFunnelId = $request->query('funnel_id') ? (int)$request->query('funnel_id') : (!empty($funnelList) ? (int)$funnelList[0]['id'] : null);

        $analyticsData = null;
        if ($selectedFunnelId) {
            $analyticsData = AnalyticsService::getFunnelMetrics($tenantId, $selectedFunnelId);
        }

        return Response::success([
            'funnels' => $funnelList,
            'selected_funnel_id' => $selectedFunnelId,
            'analytics' => $analyticsData,
        ]);
    }

    // ==========================================
    // FUNNELS CRUD & MANAGEMENT
    // ==========================================

    public function funnels(Request $request): Response
    {
        $tenantId = TenantContextService::getActiveTenantId();
        $search = $request->query('search');
        $status = $request->query('status');
        $page = (int)$request->query('page', 1);

        $funnels = FunnelService::listFunnels($tenantId, $search, $status, $page, 15);
        $usage = UsageLimitService::getUsageOverview($tenantId);
        $funnelList = isset($funnels['items']) ? $funnels['items'] : (isset($funnels['data']) ? $funnels['data'] : (is_array($funnels) ? $funnels : []));

        return Response::success([
            'funnels' => $funnelList,
            'pagination' => [
                'current_page' => $funnels['page'] ?? ($funnels['current_page'] ?? 1),
                'total_pages' => $funnels['total_pages'] ?? 1,
                'total_records' => $funnels['total'] ?? ($funnels['total_records'] ?? count($funnelList)),
                'per_page' => $funnels['per_page'] ?? 15,
            ],
            'usage' => $usage,
        ]);
    }

    public function getFunnel(Request $request, string $id): Response
    {
        $tenantId = TenantContextService::getActiveTenantId();
        $funnel = FunnelService::getFunnel($tenantId, (int)$id);

        if (!$funnel) {
            return Response::error("Funnel not found.", "NOT_FOUND", null, 404);
        }

        $formFields = FormSchemaService::getFormFields($tenantId, (int)$id);
        $settings = json_decode($funnel['settings_json'] ?? '{}', true) ?: [];
        $planFeatures = UsageLimitService::getTenantFeatures($tenantId);

        return Response::success([
            'funnel' => $funnel,
            'settings' => $settings,
            'form_fields' => $formFields,
            'plan_features' => $planFeatures,
        ]);
    }

    public function createFunnel(Request $request): Response
    {
        if (!AuthorizationService::canCreateFunnel()) {
            return Response::error("Permission denied to create funnels.", "FORBIDDEN", null, 403);
        }

        $tenantId = TenantContextService::getActiveTenantId();
        $user = current_user();

        try {
            $funnel = FunnelService::createFunnel($tenantId, $request->all(), (int)$user['id']);
            return Response::success($funnel, "Funnel created successfully.", 201);
        } catch (\Throwable $e) {
            return Response::error($e->getMessage(), "CREATE_FUNNEL_FAILED", null, 400);
        }
    }

    public function updateFunnelSettings(Request $request, string $id): Response
    {
        if (!AuthorizationService::canEditFunnel()) {
            return Response::error("Permission denied to update funnel settings.", "FORBIDDEN", null, 403);
        }

        $tenantId = TenantContextService::getActiveTenantId();
        $user = current_user();

        try {
            $existing = FunnelService::getFunnel($tenantId, (int)$id);
            if (!$existing) {
                return Response::error("Funnel not found.", "NOT_FOUND", null, 404);
            }

            $currentSettings = json_decode($existing['settings_json'] ?? '{}', true) ?: [];
            $input = $request->all();

            $canWhiteLabel = UsageLimitService::hasFeature($tenantId, 'white_label') || AuthorizationService::isPlatformAdmin();
            $requestedWhiteLabel = !empty($input['white_label']);
            $whiteLabel = $requestedWhiteLabel && $canWhiteLabel;

            $canTrackingPixels = UsageLimitService::hasFeature($tenantId, 'custom_tracking_pixels') || AuthorizationService::isPlatformAdmin();
            $fbPixel = $canTrackingPixels ? trim((string)($input['fb_pixel_id'] ?? ($currentSettings['fb_pixel_id'] ?? ''))) : ($currentSettings['fb_pixel_id'] ?? '');
            $googleTag = $canTrackingPixels ? trim((string)($input['google_tag_id'] ?? ($currentSettings['google_tag_id'] ?? ''))) : ($currentSettings['google_tag_id'] ?? '');
            $tiktokPixel = $canTrackingPixels ? trim((string)($input['tiktok_pixel_id'] ?? ($currentSettings['tiktok_pixel_id'] ?? ''))) : ($currentSettings['tiktok_pixel_id'] ?? '');

            $newSettings = array_merge($currentSettings, [
                'theme' => in_array($input['theme'] ?? '', ['light', 'dark'], true) ? $input['theme'] : ($currentSettings['theme'] ?? 'light'),
                'accent_color' => $input['accent_color'] ?? ($currentSettings['accent_color'] ?? '#5B5BD6'),
                'company_name' => trim((string)($input['company_name'] ?? ($currentSettings['company_name'] ?? ''))),
                'logo_url' => trim((string)($input['logo_url'] ?? ($currentSettings['logo_url'] ?? ''))),
                'logo_position' => in_array($input['logo_position'] ?? '', ['left', 'center', 'right'], true) ? $input['logo_position'] : ($currentSettings['logo_position'] ?? 'left'),
                'logo_height' => max(24, min(90, (int)($input['logo_height'] ?? ($currentSettings['logo_height'] ?? 36)))),
                'trust_badge_text' => trim((string)($input['trust_badge_text'] ?? ($currentSettings['trust_badge_text'] ?? ''))),
                'footer_text' => trim((string)($input['footer_text'] ?? ($currentSettings['footer_text'] ?? ''))),
                'privacy_policy_url' => trim((string)($input['privacy_policy_url'] ?? ($currentSettings['privacy_policy_url'] ?? ''))),
                'terms_url' => trim((string)($input['terms_url'] ?? ($currentSettings['terms_url'] ?? ''))),
                'white_label' => $whiteLabel,
                'card_radius' => in_array($input['card_radius'] ?? '', ['rounded-none', 'rounded-lg', 'rounded-xl', 'rounded-2xl', 'rounded-3xl'], true) ? $input['card_radius'] : ($currentSettings['card_radius'] ?? 'rounded-2xl'),
                'show_progress_bar' => isset($input['show_progress_bar']) ? (bool)$input['show_progress_bar'] : true,
                // Marketer Customization Options
                'button_radius' => in_array($input['button_radius'] ?? '', ['rounded-md', 'rounded-xl', 'rounded-2xl', 'rounded-full'], true) ? $input['button_radius'] : ($currentSettings['button_radius'] ?? 'rounded-xl'),
                'button_style' => in_array($input['button_style'] ?? '', ['solid', 'glow', 'outline'], true) ? $input['button_style'] : ($currentSettings['button_style'] ?? 'solid'),
                'cta_button_text' => trim((string)($input['cta_button_text'] ?? ($currentSettings['cta_button_text'] ?? ''))),
                'font_family' => in_array($input['font_family'] ?? '', ['sans', 'serif', 'geometric', 'system'], true) ? $input['font_family'] : ($currentSettings['font_family'] ?? 'sans'),
                'background_style' => in_array($input['background_style'] ?? '', ['default', 'dots', 'warm', 'dark'], true) ? $input['background_style'] : ($currentSettings['background_style'] ?? 'default'),
                'card_elevation' => in_array($input['card_elevation'] ?? '', ['flat', 'soft', 'floating'], true) ? $input['card_elevation'] : ($currentSettings['card_elevation'] ?? 'soft'),
                'social_proof_badge' => trim((string)($input['social_proof_badge'] ?? ($currentSettings['social_proof_badge'] ?? ''))),
                'fb_pixel_id' => $fbPixel,
                'google_tag_id' => $googleTag,
                'tiktok_pixel_id' => $tiktokPixel,
                'meta_title' => trim((string)($input['meta_title'] ?? ($currentSettings['meta_title'] ?? ''))),
                'meta_description' => trim((string)($input['meta_description'] ?? ($currentSettings['meta_description'] ?? ''))),
            ]);

            FunnelService::updateFunnel($tenantId, (int)$id, [
                'name' => $input['name'] ?? $existing['name'],
                'slug' => $input['slug'] ?? $existing['slug'],
                'description' => $input['description'] ?? $existing['description'],
                'settings' => $newSettings,
                'settings_json' => json_encode($newSettings, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            ], (int)$user['id']);

            return Response::success($newSettings, "Funnel settings updated.");
        } catch (\Throwable $e) {
            return Response::error($e->getMessage(), "UPDATE_SETTINGS_FAILED", null, 400);
        }
    }

    private function isSvgSafe(string $filePath): bool
    {
        $content = @file_get_contents($filePath);
        if ($content === false || trim($content) === '') {
            return false;
        }

        $dangerousPatterns = [
            '/<script\b/i',
            '/<foreignObject\b/i',
            '/<iframe\b/i',
            '/<object\b/i',
            '/<embed\b/i',
            '/javascript\s*:/i',
            '/data\s*:\s*text\/html/i',
            '/\bon[a-z]{3,}\s*=/i',
            '/<animate\b[^>]*\bvalues\s*=\s*[\'"][^"\']*javascript/i',
        ];

        foreach ($dangerousPatterns as $pattern) {
            if (preg_match($pattern, $content)) {
                return false;
            }
        }

        return true;
    }

    public function uploadFunnelLogo(Request $request, string $id): Response
    {
        if (!AuthorizationService::canEditFunnel()) {
            return Response::error("Permission denied to edit funnel assets.", "FORBIDDEN", null, 403);
        }

        $tenantId = TenantContextService::getActiveTenantId();
        $user = current_user();

        try {
            $existing = FunnelService::getFunnel($tenantId, (int)$id);
            if (!$existing) {
                return Response::error("Funnel not found.", "NOT_FOUND", null, 404);
            }

            $uploadedFile = $request->file('logo_file') ?? $request->file('file') ?? $request->file('logo');
            if (!$uploadedFile || $uploadedFile['error'] !== UPLOAD_ERR_OK) {
                return Response::error("Please select a valid image file to upload.", "NO_FILE", null, 400);
            }

            $allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml', 'image/gif'];
            $mimeType = null;
            if (function_exists('finfo_open')) {
                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                if ($finfo) {
                    $mimeType = finfo_file($finfo, $uploadedFile['tmp_name']);
                    if (\PHP_VERSION_ID < 80100) {
                        finfo_close($finfo);
                    }
                }
            }
            if (!$mimeType && function_exists('mime_content_type')) {
                $mimeType = mime_content_type($uploadedFile['tmp_name']);
            }

            if (!in_array($mimeType, $allowedTypes, true)) {
                return Response::error("Invalid file format. Allowed types: PNG, JPG, WebP, SVG, GIF.", "INVALID_FORMAT", null, 400);
            }

            if ($uploadedFile['size'] > 5 * 1024 * 1024) {
                return Response::error("Logo file size must be less than 5MB.", "FILE_TOO_LARGE", null, 400);
            }

            $mimeToExt = [
                'image/jpeg' => 'jpg',
                'image/png' => 'png',
                'image/webp' => 'webp',
                'image/svg+xml' => 'svg',
                'image/gif' => 'gif',
            ];
            $cleanExt = $mimeToExt[$mimeType] ?? 'png';

            if ($cleanExt === 'svg' && !$this->isSvgSafe($uploadedFile['tmp_name'])) {
                return Response::error("SVG file contains unsafe scripts or embedded objects.", "UNSAFE_SVG", null, 400);
            }

            $fileName = 'logo_' . (int)$id . '_' . bin2hex(random_bytes(6)) . '.' . $cleanExt;
            $targetDir = dirname(__DIR__, 2) . '/public/uploads/logos';
            if (!is_dir($targetDir)) {
                @mkdir($targetDir, 0755, true);
            }

            $targetPath = $targetDir . '/' . $fileName;
            $saved = is_uploaded_file($uploadedFile['tmp_name'])
                ? @move_uploaded_file($uploadedFile['tmp_name'], $targetPath)
                : @copy($uploadedFile['tmp_name'], $targetPath);

            if (!$saved) {
                return Response::error("Failed to save uploaded logo file.", "UPLOAD_SAVE_FAILED", null, 500);
            }

            $logoUrl = url('/uploads/logos/' . $fileName);

            $currentSettings = json_decode($existing['settings_json'] ?? '{}', true) ?: [];
            $currentSettings['logo_url'] = $logoUrl;

            FunnelService::updateFunnel($tenantId, (int)$id, [
                'settings' => $currentSettings,
                'settings_json' => json_encode($currentSettings, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            ], (int)$user['id']);

            return Response::success([
                'logo_url' => $logoUrl,
                'file_name' => $fileName,
            ], "Logo uploaded and saved successfully.");
        } catch (\Throwable $e) {
            return Response::error($e->getMessage(), "UPLOAD_FAILED", null, 400);
        }
    }

    public function uploadFunnelMedia(Request $request, string $id): Response
    {
        if (!AuthorizationService::canEditFunnel()) {
            return Response::error("Permission denied to edit funnel assets.", "FORBIDDEN", null, 403);
        }

        $tenantId = TenantContextService::getActiveTenantId();

        try {
            $existing = FunnelService::getFunnel($tenantId, (int)$id);
            if (!$existing) {
                return Response::error("Funnel not found.", "NOT_FOUND", null, 404);
            }

            $uploadedFile = $request->file('media_file') ?? $request->file('file') ?? $request->file('image');
            if (!$uploadedFile || $uploadedFile['error'] !== UPLOAD_ERR_OK) {
                return Response::error("Please select a valid image file to upload.", "NO_FILE", null, 400);
            }

            $allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml', 'image/gif'];
            $mimeType = null;
            if (function_exists('finfo_open')) {
                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                if ($finfo) {
                    $mimeType = finfo_file($finfo, $uploadedFile['tmp_name']);
                    if (\PHP_VERSION_ID < 80100) {
                        finfo_close($finfo);
                    }
                }
            }
            if (!$mimeType && function_exists('mime_content_type')) {
                $mimeType = mime_content_type($uploadedFile['tmp_name']);
            }

            if (!in_array($mimeType, $allowedTypes, true)) {
                return Response::error("Invalid file format. Allowed types: PNG, JPG, WebP, SVG, GIF.", "INVALID_FORMAT", null, 400);
            }

            if ($uploadedFile['size'] > 10 * 1024 * 1024) {
                return Response::error("Image file size must be less than 10MB.", "FILE_TOO_LARGE", null, 400);
            }

            $mimeToExt = [
                'image/jpeg' => 'jpg',
                'image/png' => 'png',
                'image/webp' => 'webp',
                'image/svg+xml' => 'svg',
                'image/gif' => 'gif',
            ];
            $cleanExt = $mimeToExt[$mimeType] ?? 'png';

            if ($cleanExt === 'svg' && !$this->isSvgSafe($uploadedFile['tmp_name'])) {
                return Response::error("SVG file contains unsafe scripts or embedded objects.", "UNSAFE_SVG", null, 400);
            }

            $fileName = 'media_' . (int)$id . '_' . bin2hex(random_bytes(6)) . '.' . $cleanExt;
            $targetDir = dirname(__DIR__, 2) . '/public/uploads/media';
            if (!is_dir($targetDir)) {
                @mkdir($targetDir, 0755, true);
            }

            $targetPath = $targetDir . '/' . $fileName;
            $saved = is_uploaded_file($uploadedFile['tmp_name'])
                ? @move_uploaded_file($uploadedFile['tmp_name'], $targetPath)
                : @copy($uploadedFile['tmp_name'], $targetPath);

            if (!$saved) {
                return Response::error("Failed to save uploaded image file.", "UPLOAD_SAVE_FAILED", null, 500);
            }

            $mediaUrl = url('/uploads/media/' . $fileName);
            $fullMediaUrl = full_url('/uploads/media/' . $fileName);

            return Response::success([
                'url' => $mediaUrl,
                'full_url' => $fullMediaUrl,
                'file_name' => $fileName,
            ], "Image uploaded successfully.");
        } catch (\Throwable $e) {
            return Response::error($e->getMessage(), "UPLOAD_FAILED", null, 400);
        }
    }

    public function uploadGeneralMedia(Request $request): Response
    {
        $tenantId = TenantContextService::getActiveTenantId();

        try {
            $uploadedFile = $request->file('media_file') ?? $request->file('file') ?? $request->file('image');
            if (!$uploadedFile || $uploadedFile['error'] !== UPLOAD_ERR_OK) {
                return Response::error("Please select a valid image file to upload.", "NO_FILE", null, 400);
            }

            $allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml', 'image/gif'];
            $mimeType = null;
            if (function_exists('finfo_open')) {
                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                if ($finfo) {
                    $mimeType = finfo_file($finfo, $uploadedFile['tmp_name']);
                    if (\PHP_VERSION_ID < 80100) {
                        finfo_close($finfo);
                    }
                }
            }
            if (!$mimeType && function_exists('mime_content_type')) {
                $mimeType = mime_content_type($uploadedFile['tmp_name']);
            }

            if (!in_array($mimeType, $allowedTypes, true)) {
                return Response::error("Invalid file format. Allowed types: PNG, JPG, WebP, SVG, GIF.", "INVALID_FORMAT", null, 400);
            }

            if ($uploadedFile['size'] > 10 * 1024 * 1024) {
                return Response::error("Image file size must be less than 10MB.", "FILE_TOO_LARGE", null, 400);
            }

            $mimeToExt = [
                'image/jpeg' => 'jpg',
                'image/png' => 'png',
                'image/webp' => 'webp',
                'image/svg+xml' => 'svg',
                'image/gif' => 'gif',
            ];
            $cleanExt = $mimeToExt[$mimeType] ?? 'png';

            if ($cleanExt === 'svg' && !$this->isSvgSafe($uploadedFile['tmp_name'])) {
                return Response::error("SVG file contains unsafe scripts or embedded objects.", "UNSAFE_SVG", null, 400);
            }

            $fileName = 'media_t' . (int)$tenantId . '_' . bin2hex(random_bytes(6)) . '.' . $cleanExt;
            $targetDir = dirname(__DIR__, 2) . '/public/uploads/media';
            if (!is_dir($targetDir)) {
                @mkdir($targetDir, 0755, true);
            }

            $targetPath = $targetDir . '/' . $fileName;
            $saved = is_uploaded_file($uploadedFile['tmp_name'])
                ? @move_uploaded_file($uploadedFile['tmp_name'], $targetPath)
                : @copy($uploadedFile['tmp_name'], $targetPath);

            if (!$saved) {
                return Response::error("Failed to save uploaded image file.", "UPLOAD_SAVE_FAILED", null, 500);
            }

            $mediaUrl = url('/uploads/media/' . $fileName);
            $fullMediaUrl = full_url('/uploads/media/' . $fileName);

            return Response::success([
                'url' => $mediaUrl,
                'full_url' => $fullMediaUrl,
                'file_name' => $fileName,
            ], "Image uploaded successfully.");
        } catch (\Throwable $e) {
            return Response::error($e->getMessage(), "UPLOAD_FAILED", null, 400);
        }
    }

    public function duplicateFunnel(Request $request, string $id): Response
    {
        if (!AuthorizationService::canCreateFunnel()) {
            return Response::error("Permission denied to duplicate funnels.", "FORBIDDEN", null, 403);
        }

        $tenantId = TenantContextService::getActiveTenantId();
        $user = current_user();

        try {
            $clone = FunnelService::duplicateFunnel($tenantId, (int)$id, (int)$user['id']);
            return Response::success($clone, "Funnel duplicated successfully.");
        } catch (\Throwable $e) {
            return Response::error($e->getMessage(), "DUPLICATE_FAILED", null, 400);
        }
    }

    public function publishFunnel(Request $request, string $id): Response
    {
        if (!AuthorizationService::canPublishFunnel()) {
            return Response::error("Permission denied to publish funnels.", "FORBIDDEN", null, 403);
        }

        $tenantId = TenantContextService::getActiveTenantId();
        $user = current_user();

        try {
            $published = FunnelPublishService::publish($tenantId, (int)$id, (int)$user['id']);
            return Response::success($published, "Funnel published successfully.");
        } catch (\Throwable $e) {
            return Response::error($e->getMessage(), "PUBLISH_FAILED", null, 400);
        }
    }

    public function unpublishFunnel(Request $request, string $id): Response
    {
        if (!AuthorizationService::canPublishFunnel()) {
            return Response::error("Permission denied to unpublish funnels.", "FORBIDDEN", null, 403);
        }

        $tenantId = TenantContextService::getActiveTenantId();
        $user = current_user();

        try {
            $funnel = FunnelPublishService::unpublish($tenantId, (int)$id, (int)$user['id']);
            return Response::success($funnel, "Funnel unpublished successfully.");
        } catch (\Throwable $e) {
            return Response::error($e->getMessage(), "UNPUBLISH_FAILED", null, 400);
        }
    }

    public function deleteFunnel(Request $request, string $id): Response
    {
        if (!AuthorizationService::canDeleteFunnel()) {
            return Response::error("Permission denied to delete funnels.", "FORBIDDEN", null, 403);
        }

        $tenantId = TenantContextService::getActiveTenantId();
        $user = current_user();

        try {
            FunnelService::deleteFunnel($tenantId, (int)$id, (int)$user['id']);
            return Response::success(null, "Funnel deleted successfully.");
        } catch (\Throwable $e) {
            return Response::error($e->getMessage(), "DELETE_FAILED", null, 400);
        }
    }

    public function getFunnelGraph(Request $request, string $id): Response
    {
        $tenantId = TenantContextService::getActiveTenantId();

        try {
            $graph = FunnelGraphService::getGraph($tenantId, (int)$id);
            return Response::success($graph);
        } catch (\Throwable $e) {
            return Response::error($e->getMessage(), 'GRAPH_ERROR', null, 404);
        }
    }

    public function saveFunnelGraph(Request $request, string $id): Response
    {
        if (!AuthorizationService::canEditFunnel()) {
            return Response::error("Permission denied.", "FORBIDDEN", null, 403);
        }

        $tenantId = TenantContextService::getActiveTenantId();
        $user = current_user();
        $payload = $request->all();

        try {
            $savedGraph = FunnelGraphService::saveGraph($tenantId, (int)$id, $payload, (int)$user['id']);
            return Response::success($savedGraph, 'Graph saved successfully.');
        } catch (\Throwable $e) {
            return Response::error($e->getMessage(), 'SAVE_ERROR', null, 400);
        }
    }

    public function validateFunnelGraph(Request $request, string $id): Response
    {
        $tenantId = TenantContextService::getActiveTenantId();

        try {
            $validation = FunnelGraphService::validateGraph($tenantId, (int)$id);
            return Response::success($validation);
        } catch (\Throwable $e) {
            return Response::error($e->getMessage(), 'VALIDATION_ERROR', null, 400);
        }
    }

    public function updateFunnelMode(Request $request, string $id): Response
    {
        if (!AuthorizationService::canEditFunnel()) {
            return Response::error("Permission denied to modify funnel mode.", "FORBIDDEN", null, 403);
        }

        $tenantId = TenantContextService::getActiveTenantId();
        $user = current_user();
        $mode = $request->input('funnel_mode');

        if (!in_array($mode, ['quiz', 'calculator'], true)) {
            return Response::error('Invalid funnel mode.', 'INVALID_MODE', null, 400);
        }

        if ($mode === 'calculator' && !UsageLimitService::hasFeature($tenantId, 'calculator_mode') && !AuthorizationService::isPlatformAdmin()) {
            return Response::error("Calculator & Quote Mode is not included in your current subscription plan. Please upgrade to unlock.", "FEATURE_LOCKED", null, 403);
        }

        try {
            FunnelService::updateFunnel($tenantId, (int)$id, ['funnel_mode' => $mode], (int)$user['id']);
            return Response::success(['funnel_mode' => $mode], "Funnel mode updated to '{$mode}'.");
        } catch (\Throwable $e) {
            return Response::error($e->getMessage(), 'UPDATE_ERROR', null, 400);
        }
    }

    public function saveFunnelFormFields(Request $request, string $id): Response
    {
        if (!AuthorizationService::canEditFunnel()) {
            return Response::error("Permission denied to modify lead capture fields.", "FORBIDDEN", null, 403);
        }

        $tenantId = TenantContextService::getActiveTenantId();
        $user = current_user();
        $fields = $request->input('fields', []);

        try {
            $saved = FormSchemaService::saveFormFields($tenantId, (int)$id, $fields, (int)$user['id']);
            return Response::success($saved, 'Pre-quiz form fields saved successfully.');
        } catch (\Throwable $e) {
            return Response::error($e->getMessage(), 'SAVE_ERROR', null, 400);
        }
    }

    // ==========================================
    // SUBMISSIONS & LEADS CRM
    // ==========================================

    public function submissions(Request $request): Response
    {
        $tenantId = TenantContextService::getActiveTenantId();

        $filters = [
            'tab' => $request->query('tab', 'qualified'),
            'funnel_id' => $request->query('funnel_id'),
            'status' => $request->query('status'),
            'lead_status' => $request->query('lead_status'),
            'date_range' => $request->query('date_range'),
            'search' => trim((string)$request->query('search', '')),
        ];
        $page = (int)$request->query('page', 1);

        $submissions = SubmissionService::listSubmissions($tenantId, $filters, $page, 15);
        $subList = isset($submissions['items']) ? $submissions['items'] : (isset($submissions['data']) ? $submissions['data'] : (is_array($submissions) ? $submissions : []));
        $funnels = FunnelService::listFunnels($tenantId);
        $funnelList = isset($funnels['items']) ? $funnels['items'] : (isset($funnels['data']) ? $funnels['data'] : (is_array($funnels) ? $funnels : []));
        $leadStages = LeadStageService::getStagesForTenant($tenantId);

        return Response::success([
            'submissions' => $subList,
            'counts' => $submissions['counts'] ?? ['all' => 0, 'qualified' => 0, 'abandoned' => 0],
            'pagination' => [
                'current_page' => $submissions['page'] ?? ($submissions['current_page'] ?? 1),
                'total_pages' => $submissions['total_pages'] ?? 1,
                'total_records' => $submissions['total'] ?? ($submissions['total_records'] ?? count($subList)),
                'per_page' => $submissions['per_page'] ?? 15,
            ],
            'funnels' => $funnelList,
            'lead_stages' => $leadStages,
            'filters' => $filters,
        ]);
    }

    public function submissionDetail(Request $request, string $id): Response
    {
        $tenantId = TenantContextService::getActiveTenantId();
        $detail = SubmissionService::getSubmissionDetail($tenantId, (int)$id);

        if (!$detail) {
            return Response::error("Submission record not found.", "NOT_FOUND", null, 404);
        }

        $leadStages = LeadStageService::getStagesForTenant($tenantId);

        return Response::success([
            'submission' => $detail,
            'lead_stages' => $leadStages,
        ]);
    }

    public function updateSubmissionStatus(Request $request, string $id): Response
    {
        $tenantId = TenantContextService::getActiveTenantId();
        $leadStatus = (string)$request->input('lead_status');

        $updated = SubmissionService::updateLeadStatus($tenantId, (int)$id, $leadStatus);
        if (!$updated) {
            return Response::error("Invalid lead status provided.", "INVALID_STATUS", null, 400);
        }

        return Response::success(['lead_status' => $leadStatus], "Status updated.");
    }

    public function bulkSubmissionsAction(Request $request): Response
    {
        $tenantId = TenantContextService::getActiveTenantId();
        $action = (string)$request->input('action');
        $sessionIds = (array)$request->input('session_ids', []);

        if (empty($sessionIds)) {
            return Response::error("No leads were selected.", "NO_SELECTION", null, 400);
        }

        if (str_starts_with($action, 'mark_')) {
            $newStatus = substr($action, 5);
            $count = SubmissionService::bulkUpdateLeadStatus($tenantId, $sessionIds, $newStatus);
            return Response::success(['count' => $count], "{$count} leads updated.");
        } elseif ($action === 'delete') {
            if (!AuthorizationService::canManageWorkspace()) {
                return Response::error("Permission denied: Workspace management privileges required to delete leads.", "FORBIDDEN", null, 403);
            }
            $count = SubmissionService::bulkDelete($tenantId, $sessionIds);
            return Response::success(['count' => $count], "{$count} leads deleted.");
        }

        return Response::error("Unknown bulk action.", "INVALID_ACTION", null, 400);
    }

    public function exportSubmissions(Request $request): void
    {
        if (!AuthorizationService::canExportSubmissions()) {
            http_response_code(403);
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'Permission denied: Only workspace owners and admins can export lead data.',
                'error_code' => 'FORBIDDEN'
            ]);
            exit;
        }

        $tenantId = TenantContextService::getActiveTenantId();

        if (!AuthorizationService::isPlatformAdmin() && !UsageLimitService::hasFeature($tenantId, 'csv_export')) {
            http_response_code(403);
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'CSV lead export is only available on Pro or Enterprise plans.',
                'error_code' => 'FEATURE_LOCKED'
            ]);
            exit;
        }

        $funnelId = $request->query('funnel_id') ? (int)$request->query('funnel_id') : null;
        $tab = $request->query('tab');
        $filters = [
            'date_range' => $request->query('date_range'),
        ];

        $csv = SubmissionService::exportCsv($tenantId, $funnelId, $tab, $filters);
        $filename = 'leads_export_' . date('Y-m-d_His') . '.csv';

        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Pragma: no-cache');
        header('Expires: 0');
        echo $csv;
        exit;
    }

    public function listLeadStages(Request $request): Response
    {
        $tenantId = TenantContextService::getActiveTenantId();
        $stages = LeadStageService::getStagesForTenant($tenantId);
        return Response::success($stages);
    }

    public function createLeadStage(Request $request): Response
    {
        if (!AuthorizationService::canManageWorkspace()) {
            return Response::error("Permission denied: Workspace management privileges required.", "FORBIDDEN", null, 403);
        }

        $tenantId = TenantContextService::getActiveTenantId();
        $name = trim((string)$request->input('name'));
        $color = (string)$request->input('color', '#6366F1');

        if (empty($name)) {
            return Response::error("Stage name is required.", "VALIDATION_FAILED", null, 400);
        }

        $stage = LeadStageService::createStage($tenantId, $name, $color);
        return Response::success($stage, "Stage created successfully.", 201);
    }

    public function deleteLeadStage(Request $request, string $id): Response
    {
        if (!AuthorizationService::canManageWorkspace()) {
            return Response::error("Permission denied: Workspace management privileges required.", "FORBIDDEN", null, 403);
        }

        $tenantId = TenantContextService::getActiveTenantId();
        LeadStageService::deleteStage($tenantId, (int)$id);
        return Response::success(null, "Stage deleted.");
    }

    // ==========================================
    // TEAM & MEMBERSHIP
    // ==========================================

    public function team(Request $request): Response
    {
        $tenantId = TenantContextService::getActiveTenantId();
        $members = Database::query(
            "SELECT tm.id as membership_id, tm.role, tm.created_at, u.id as user_id, u.name, u.email, u.status, u.last_login_at 
             FROM tenant_memberships tm
             JOIN users u ON tm.user_id = u.id
             WHERE tm.tenant_id = ?
             ORDER BY tm.id ASC",
            [$tenantId]
        );

        $currentUserRole = TenantContextService::getCurrentRole();
        $usage = UsageLimitService::getUsageOverview($tenantId);

        return Response::success([
            'members' => $members,
            'current_user_role' => $currentUserRole,
            'usage' => $usage,
        ]);
    }

    public function inviteTeamMember(Request $request): Response
    {
        if (!AuthorizationService::canManageTeam()) {
            return Response::error("Permission denied: Only workspace owners and admins can invite team members.", "FORBIDDEN", null, 403);
        }

        $tenantId = TenantContextService::getActiveTenantId();

        if (!AuthorizationService::isPlatformAdmin()) {
            $seatCheck = UsageLimitService::checkCanAddTeamMember($tenantId);
            if (!$seatCheck['allowed']) {
                return Response::error($seatCheck['message'], "LIMIT_REACHED", $seatCheck, 403);
            }
        }

        $email = trim(strtolower((string)$request->input('email')));
        $name = trim((string)$request->input('name', ''));
        $role = (string)$request->input('role', 'editor');
        $rawPassword = trim((string)$request->input('password', ''));

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return Response::error("Invalid email address.", "VALIDATION_FAILED", null, 400);
        }

        if (empty($rawPassword)) {
            $rawPassword = 'FF-' . bin2hex(random_bytes(3)) . '@' . rand(10, 99);
        }

        if (strlen($rawPassword) < 8) {
            return Response::error("Password must be at least 8 characters long.", "VALIDATION_FAILED", null, 400);
        }

        $activeTenant = TenantContextService::getActiveTenant();
        $currentUser = current_user();
        $workspaceName = $activeTenant['name'] ?? 'Workspace';
        $invitedByName = $currentUser['name'] ?? 'Workspace Administrator';
        $appUrl = rtrim(Env::get('APP_URL', 'https://filterfunnel.in'), '/');
        $loginUrl = "{$appUrl}/login";

        $isNewUser = false;
        // Check if user exists
        $user = Database::fetchOne("SELECT * FROM users WHERE email = ?", [$email]);
        if (!$user) {
            $isNewUser = true;
            $passwordHash = password_hash($rawPassword, PASSWORD_DEFAULT);
            $displayName = $name ?: explode('@', $email)[0];
            Database::execute(
                "INSERT INTO users (name, email, password_hash, status, email_verified_at) VALUES (?, ?, ?, 'active', NOW())",
                [$displayName, $email, $passwordHash]
            );
            $userId = (int)Database::lastInsertId();

            // Send invitation email with credentials via configured Super Admin SMTP
            try {
                $mailRes = MailService::sendTemplate('team_invitation', $email, $displayName, [
                    'workspace_name' => $workspaceName,
                    'role' => ucfirst($role),
                    'invited_by_name' => $invitedByName,
                    'password' => $rawPassword,
                    'login_url' => $loginUrl,
                ]);
                if (!empty($mailRes['success'])) {
                    Logger::info("Team invitation email successfully dispatched to {$email} via configured SMTP.");
                } else {
                    Logger::warning("Team invitation email to {$email} returned: " . ($mailRes['message'] ?? ''));
                }
            } catch (\Throwable $e) {
                Logger::error("Failed to send team invitation email to {$email}: " . $e->getMessage());
            }
        } else {
            $userId = (int)$user['id'];
            $displayName = $user['name'] ?: ($name ?: explode('@', $email)[0]);

            // Send existing user notification email via configured Super Admin SMTP
            try {
                $mailRes = MailService::sendTemplate('team_member_added', $email, $displayName, [
                    'workspace_name' => $workspaceName,
                    'role' => ucfirst($role),
                    'invited_by_name' => $invitedByName,
                    'login_url' => $loginUrl,
                ]);
                if (!empty($mailRes['success'])) {
                    Logger::info("Team access email successfully dispatched to {$email} via configured SMTP.");
                } else {
                    Logger::warning("Team access email to {$email} returned: " . ($mailRes['message'] ?? ''));
                }
            } catch (\Throwable $e) {
                Logger::error("Failed to send team access email to {$email}: " . $e->getMessage());
            }
        }

        // Check existing membership
        $existing = Database::fetchOne("SELECT id FROM tenant_memberships WHERE tenant_id = ? AND user_id = ?", [$tenantId, $userId]);
        if ($existing) {
            return Response::error("User is already a member of this workspace.", "ALREADY_MEMBER", null, 400);
        }

        Database::execute(
            "INSERT INTO tenant_memberships (tenant_id, user_id, role) VALUES (?, ?, ?)",
            [$tenantId, $userId, $role]
        );

        return Response::success([
            'is_new_user' => $isNewUser,
            'name' => $displayName,
            'email' => $email,
            'role' => $role,
            'password' => $isNewUser ? $rawPassword : null,
            'workspace_name' => $workspaceName,
            'login_url' => $loginUrl,
        ], $isNewUser ? "Team member added and credentials sent to {$email}." : "Existing user added to workspace successfully.", 201);
    }

    public function updateTeamMember(Request $request, string $id): Response
    {
        if (!AuthorizationService::canManageTeam()) {
            return Response::error("Permission denied: Only workspace owners and admins can update team members.", "FORBIDDEN", null, 403);
        }

        $tenantId = TenantContextService::getActiveTenantId();
        $role = (string)$request->input('role');

        if (!in_array($role, ['owner', 'admin', 'editor', 'analyst'], true)) {
            return Response::error("Invalid role.", "INVALID_ROLE", null, 400);
        }

        $currentRole = TenantContextService::getCurrentRole();
        if ($role === 'owner' && $currentRole !== 'owner' && !AuthorizationService::isPlatformAdmin()) {
            return Response::error("Only the workspace owner can transfer ownership.", "FORBIDDEN", null, 403);
        }

        Database::execute("UPDATE tenant_memberships SET role = ? WHERE id = ? AND tenant_id = ?", [$role, (int)$id, $tenantId]);
        return Response::success(null, "Role updated.");
    }

    public function removeTeamMember(Request $request, string $id): Response
    {
        if (!AuthorizationService::canManageTeam()) {
            return Response::error("Permission denied: Only workspace owners and admins can remove team members.", "FORBIDDEN", null, 403);
        }

        $tenantId = TenantContextService::getActiveTenantId();
        $target = Database::fetchOne("SELECT role, user_id FROM tenant_memberships WHERE id = ? AND tenant_id = ?", [(int)$id, $tenantId]);
        if (!$target) {
            return Response::error("Member not found in this workspace.", "NOT_FOUND", null, 404);
        }

        if ($target['role'] === 'owner' && !AuthorizationService::isPlatformAdmin()) {
            return Response::error("The workspace owner cannot be removed.", "ACTION_NOT_ALLOWED", null, 400);
        }

        Database::execute("DELETE FROM tenant_memberships WHERE id = ? AND tenant_id = ?", [(int)$id, $tenantId]);
        return Response::success(null, "Member removed.");
    }

    // ==========================================
    // WEBHOOKS
    // ==========================================

    public function webhooks(Request $request): Response
    {
        $tenantId = TenantContextService::getActiveTenantId();
        $endpoints = Database::query(
            "SELECT * FROM webhook_endpoints WHERE tenant_id = ? ORDER BY id DESC",
            [$tenantId]
        );

        $recentDeliveries = Database::query(
            "SELECT wd.*, we.target_url 
             FROM webhook_deliveries wd
             JOIN webhook_endpoints we ON wd.webhook_endpoint_id = we.id
             WHERE we.tenant_id = ?
             ORDER BY wd.id DESC LIMIT 20",
            [$tenantId]
        );

        $funnels = FunnelService::listFunnels($tenantId);
        $funnelList = isset($funnels['items']) ? $funnels['items'] : (isset($funnels['data']) ? $funnels['data'] : (is_array($funnels) ? $funnels : []));

        return Response::success([
            'endpoints' => $endpoints,
            'recent_deliveries' => $recentDeliveries,
            'funnels' => $funnelList,
        ]);
    }

    public function createWebhook(Request $request): Response
    {
        if (!AuthorizationService::canManageWorkspace()) {
            return Response::error("Permission denied: Workspace management privileges required.", "FORBIDDEN", null, 403);
        }

        $tenantId = TenantContextService::getActiveTenantId();

        if (!AuthorizationService::isPlatformAdmin() && !UsageLimitService::hasFeature($tenantId, 'webhooks')) {
            return Response::error("Outbound webhooks are only available on Pro or Enterprise plans.", "FEATURE_LOCKED", null, 403);
        }

        $targetUrl = trim((string)$request->input('target_url'));
        $eventType = (string)$request->input('event_type', 'all');
        $funnelId = $request->input('funnel_id') ? (int)$request->input('funnel_id') : null;
        $secret = trim((string)$request->input('secret', '')) ?: bin2hex(random_bytes(16));

        if (!filter_var($targetUrl, FILTER_VALIDATE_URL)) {
            return Response::error("Valid target URL is required.", "INVALID_URL", null, 400);
        }

        Database::execute(
            "INSERT INTO webhook_endpoints (tenant_id, target_url, event_type, funnel_id, secret, is_active) VALUES (?, ?, ?, ?, ?, 1)",
            [$tenantId, $targetUrl, $eventType, $funnelId, $secret]
        );

        return Response::success(['id' => Database::lastInsertId()], "Webhook created.", 201);
    }

    public function deleteWebhook(Request $request, string $id): Response
    {
        if (!AuthorizationService::canManageWorkspace()) {
            return Response::error("Permission denied: Workspace management privileges required.", "FORBIDDEN", null, 403);
        }

        $tenantId = TenantContextService::getActiveTenantId();
        Database::execute("DELETE FROM webhook_endpoints WHERE id = ? AND tenant_id = ?", [(int)$id, $tenantId]);
        return Response::success(null, "Webhook deleted.");
    }

    // ==========================================
    // BILLING & SUBSCRIPTION
    // ==========================================

    public function billing(Request $request): Response
    {
        $tenantId = TenantContextService::getActiveTenantId();
        $tenant = TenantContextService::getActiveTenant();

        $sub = SubscriptionService::getActiveSubscription($tenantId);
        $billing = SubscriptionService::getBillingSummary($tenantId);
        $usage = UsageLimitService::getUsageOverview($tenantId);

        $currentPlanId = $sub['plan_id'] ?? 0;
        $plans = Database::query(
            "SELECT * FROM plans WHERE is_active = 1 AND (is_visible = 1 OR id = ?) ORDER BY price ASC, id ASC",
            [$currentPlanId]
        );
        $featureCatalog = UsageLimitService::getFeatureCatalog();
        $gateways = PlatformSettingService::getPaymentGateways();
        $invoices = SubscriptionService::getInvoices($tenantId);

        return Response::success([
            'tenant' => $tenant,
            'subscription' => $sub,
            'billing' => $billing,
            'usage' => $usage,
            'plans' => $plans,
            'feature_catalog' => $featureCatalog,
            'gateways' => $gateways,
            'invoices' => $invoices,
            'can_manage_billing' => in_array(TenantContextService::getCurrentRole(), ['owner', 'admin'], true) || AuthorizationService::isPlatformAdmin(),
        ]);
    }

    public function upgradePlan(Request $request): Response
    {
        $tenantId = TenantContextService::getActiveTenantId();
        if (!$tenantId) {
            return Response::error("Active workspace required.", "NO_WORKSPACE", null, 400);
        }

        $user = current_user();
        if (!$user) {
            return Response::error("Authentication required.", "UNAUTHENTICATED", null, 401);
        }

        $role = TenantContextService::getCurrentRole();
        if (!in_array($role, ['owner', 'admin'], true) && !AuthorizationService::isPlatformAdmin()) {
            return Response::error("You need owner or admin permission to modify subscription plans.", "FORBIDDEN", null, 403);
        }

        $planId = (int)$request->input('plan_id');
        $interval = (string)$request->input('billing_interval', '');
        $paymentMethod = (string)$request->input('payment_method', 'direct_activation');
        $txnRef = trim((string)$request->input('transaction_reference', ''));

        $sub = SubscriptionService::getActiveSubscription($tenantId);
        $currentPlanId = $sub['plan_id'] ?? 0;
        $targetPlan = Database::fetchOne("SELECT * FROM plans WHERE id = ? AND is_active = 1 AND (is_visible = 1 OR id = ?)", [$planId, $currentPlanId]);
        if (!$targetPlan) {
            return Response::error("Selected plan is invalid or currently inactive.", "INVALID_PLAN", null, 404);
        }

        if (empty($interval)) {
            $interval = $targetPlan['billing_interval'] ?? 'monthly';
        }

        // Enforce Upgrade-Only Policy (Downgrades and re-selecting current tier are prohibited)
        $existingSub = SubscriptionService::getActiveSubscription($tenantId);
        $currentPlanPrice = 0.0;
        if ($existingSub && !empty($existingSub['plan_id'])) {
            $currentPlan = Database::fetchOne("SELECT price FROM plans WHERE id = ?", [$existingSub['plan_id']]);
            if ($currentPlan) {
                $currentPlanPrice = (float)$currentPlan['price'];
            }
        }

        $targetPrice = (float)$targetPlan['price'];

        if ($existingSub && !empty($existingSub['plan_id'])) {
            $isTenantSuspended = false;
            $tenantRow = Database::fetchOne("SELECT status FROM tenants WHERE id = ?", [$tenantId]);
            if ($tenantRow && $tenantRow['status'] === 'suspended') {
                $isTenantSuspended = true;
            }

            if (!$isTenantSuspended && (int)$targetPlan['id'] === (int)$existingSub['plan_id']) {
                return Response::error("You are already active on the '{$targetPlan['name']}' plan. You can only upgrade to a higher tier plan.", "PLAN_ALREADY_ACTIVE", null, 400);
            }

            if ($targetPrice < $currentPlanPrice) {
                return Response::error("Downgrading to a lower tier plan is not permitted. You can only upgrade to a higher tier plan.", "DOWNGRADE_NOT_PERMITTED", null, 400);
            }
        }

        $price = $targetPrice;
        if ($interval === 'lifetime' || ($targetPlan['billing_interval'] ?? '') === 'lifetime') {
            $interval = 'lifetime';
            $amount = $price;
            $currentPeriodEnd = '2099-12-31 23:59:59';
        } elseif ($interval === 'yearly') {
            $amount = $price * 12 * 0.85; // 15% discount for annual billing
            $currentPeriodEnd = date('Y-m-d H:i:s', strtotime('+1 year'));
        } elseif ($interval === 'semi_annual') {
            $amount = $price * 6 * 0.90;
            $currentPeriodEnd = date('Y-m-d H:i:s', strtotime('+6 months'));
        } elseif ($interval === 'quarterly') {
            $amount = $price * 3 * 0.95;
            $currentPeriodEnd = date('Y-m-d H:i:s', strtotime('+3 months'));
        } else {
            $amount = $price;
            $currentPeriodEnd = date('Y-m-d H:i:s', strtotime('+1 month'));
        }

        try {
            $invoiceNumber = 'INV-' . date('Y') . '-' . str_pad((string)$tenantId, 4, '0', STR_PAD_LEFT) . '-' . strtoupper(bin2hex(random_bytes(2)));
            $periodStart = date('Y-m-d');
            $periodEnd = date('Y-m-d', strtotime($currentPeriodEnd));

            Database::execute(
                "INSERT INTO tenant_invoices 
                 (tenant_id, invoice_number, amount, currency, status, billing_interval, period_start, period_end, payment_method, transaction_reference, notes, paid_at)
                 VALUES (?, ?, ?, 'INR', 'paid', ?, ?, ?, ?, ?, ?, NOW())",
                [
                    $tenantId,
                    $invoiceNumber,
                    $amount,
                    $interval,
                    $periodStart,
                    $periodEnd,
                    $paymentMethod,
                    $txnRef ?: 'Self-Service Customer Upgrade',
                    "Upgraded to {$targetPlan['name']} plan by {$user['name']} ({$user['email']})"
                ]
            );

            if ($existingSub) {
                Database::execute(
                    "UPDATE tenant_subscriptions 
                     SET plan_id = ?, status = 'active', billing_interval = ?, current_period_start = NOW(), 
                         current_period_end = ?, ends_at = ?, next_billing_date = ?, amount = ?, currency = 'INR', provider = ?
                     WHERE id = ?",
                    [
                        $planId, $interval, $currentPeriodEnd, $currentPeriodEnd, $currentPeriodEnd, 
                        $amount, $paymentMethod, $existingSub['id']
                    ]
                );
            } else {
                Database::execute(
                    "INSERT INTO tenant_subscriptions 
                     (tenant_id, plan_id, status, billing_interval, starts_at, ends_at, current_period_start, current_period_end, next_billing_date, amount, currency, provider)
                     VALUES (?, ?, 'active', ?, NOW(), ?, NOW(), ?, ?, ?, 'INR', ?)",
                    [
                        $tenantId, $planId, $interval, $currentPeriodEnd, $currentPeriodEnd, $currentPeriodEnd, $amount, $paymentMethod
                    ]
                );
            }

            // Unsuspend workspace if suspended
            $tenant = Database::fetchOne("SELECT status FROM tenants WHERE id = ?", [$tenantId]);
            if ($tenant && $tenant['status'] === 'suspended') {
                SubscriptionService::unsuspendWorkspace($tenantId, $currentPeriodEnd, (int)$user['id']);
            }

            AuditLogService::log($tenantId, (int)$user['id'], 'upgrade_subscription_plan', 'tenant_subscription', $planId, [
                'plan_name' => $targetPlan['name'],
                'interval' => $interval,
                'amount' => $amount,
                'invoice_number' => $invoiceNumber
            ]);

            return Response::success([
                'plan_name' => $targetPlan['name'],
                'invoice_number' => $invoiceNumber,
                'amount' => $amount,
                'billing_interval' => $interval,
            ], "Successfully upgraded to {$targetPlan['name']}!");
        } catch (\Throwable $e) {
            return Response::error("Failed to process plan upgrade: " . $e->getMessage(), "UPGRADE_FAILED", null, 500);
        }
    }

    public function createCashfreeOrder(Request $request): Response
    {
        $tenantId = TenantContextService::getActiveTenantId();
        if (!$tenantId) {
            return Response::error("Active workspace required.", "NO_WORKSPACE", null, 400);
        }

        $user = current_user();
        if (!$user) {
            return Response::error("Authentication required.", "UNAUTHENTICATED", null, 401);
        }

        $planId = (int)$request->input('plan_id');
        $plan = Database::fetchOne("SELECT * FROM plans WHERE id = ? AND is_active = 1", [$planId]);
        if (!$plan) {
            return Response::error("Selected subscription plan not found.", "NOT_FOUND", null, 404);
        }

        // If plan is completely free (0.00), handle immediate upgrade without checkout
        if ((float)$plan['price'] <= 0) {
            SubscriptionService::assignPlan($tenantId, $planId, 30, (int)$user['id'], 'Free Plan Selection');
            return Response::success([
                'free_plan' => true,
                'plan_name' => $plan['name'],
            ], "Successfully updated to {$plan['name']}!");
        }

        $returnUrl = (string)$request->input('return_url', '');

        try {
            $orderData = CashfreeService::createOrder($tenantId, $user, $plan, !empty($returnUrl) ? $returnUrl : null);
            return Response::success($orderData, "Cashfree order initialized successfully.");
        } catch (\Throwable $e) {
            return Response::error("Cashfree order creation failed: " . $e->getMessage(), "CASHFREE_ERROR", null, 400);
        }
    }

    public function verifyCashfreePayment(Request $request): Response
    {
        $tenantId = TenantContextService::getActiveTenantId();
        if (!$tenantId) {
            return Response::error("Active workspace required.", "NO_WORKSPACE", null, 400);
        }

        $user = current_user();
        if (!$user) {
            return Response::error("Authentication required.", "UNAUTHENTICATED", null, 401);
        }

        $orderId = trim((string)$request->input('order_id', ''));
        $planId = (int)$request->input('plan_id');

        if (empty($orderId) || $planId <= 0) {
            return Response::error("Order ID and Plan ID are required for verification.", "VALIDATION_FAILED", null, 400);
        }

        try {
            $result = CashfreeService::verifyAndActivate($tenantId, $planId, $orderId, (int)$user['id']);
            return Response::success($result, "Payment successfully verified! Your subscription is active.");
        } catch (\Throwable $e) {
            return Response::error("Payment verification failed: " . $e->getMessage(), "VERIFICATION_FAILED", null, 400);
        }
    }

    public function cashfreeWebhook(Request $request): Response
    {
        $raw = file_get_contents('php://input');
        $payload = json_decode($raw, true);

        if (!$payload || !is_array($payload)) {
            return Response::success(null, "Ignored empty payload.");
        }

        // Handle Cashfree standard event
        $data = $payload['data'] ?? $payload;
        $order = $data['order'] ?? $data;
        $orderId = (string)($order['order_id'] ?? '');

        if (!empty($orderId)) {
            // Check if order format is cf_t{tenantId}_p{planId}_...
            if (preg_match('/^cf_t(\d+)_p(\d+)_/', $orderId, $matches)) {
                $tenantId = (int)$matches[1];
                $planId = (int)$matches[2];
                try {
                    CashfreeService::verifyAndActivate($tenantId, $planId, $orderId, 1);
                } catch (\Throwable $e) {
                    \App\Core\Logger::error("Cashfree webhook activation failed: " . $e->getMessage());
                }
            }
        }

        return Response::success(null, "Webhook processed.");
    }

    // ==========================================
    // SETTINGS & PROFILE
    // ==========================================

    public function updateWorkspace(Request $request): Response
    {
        if (!AuthorizationService::canManageWorkspace()) {
            return Response::error("Permission denied: Workspace management privileges required.", "FORBIDDEN", null, 403);
        }

        $tenantId = TenantContextService::getActiveTenantId();
        if (!$tenantId) {
            return Response::error("Active workspace required.", "NO_WORKSPACE", null, 400);
        }

        $name = trim((string)$request->input('name'));
        if (empty($name)) {
            return Response::error("Workspace name cannot be empty.", "VALIDATION_FAILED", null, 400);
        }

        if ($request->input('remove_logo')) {
            Database::execute("UPDATE tenants SET name = ?, logo_url = NULL WHERE id = ?", [$name, $tenantId]);
        } elseif ($request->has('logo_url')) {
            $logoUrl = trim((string)$request->input('logo_url')) ?: null;
            Database::execute("UPDATE tenants SET name = ?, logo_url = ? WHERE id = ?", [$name, $logoUrl, $tenantId]);
        } else {
            Database::execute("UPDATE tenants SET name = ? WHERE id = ?", [$name, $tenantId]);
        }

        $updated = Database::fetchOne("SELECT id, name, slug, logo_url, status FROM tenants WHERE id = ?", [$tenantId]);
        return Response::success($updated, "Workspace updated successfully.");
    }

    public function uploadWorkspaceLogo(Request $request): Response
    {
        if (!AuthorizationService::canManageWorkspace()) {
            return Response::error("Permission denied: Workspace management privileges required.", "FORBIDDEN", null, 403);
        }

        $tenantId = TenantContextService::getActiveTenantId();
        if (!$tenantId) {
            return Response::error("Active workspace required.", "NO_WORKSPACE", null, 400);
        }

        $uploaded = $_FILES['logo'] ?? $_FILES['file'] ?? null;
        if (!$uploaded || $uploaded['error'] !== UPLOAD_ERR_OK) {
            return Response::error("No logo file uploaded or upload error occurred.", "NO_FILE", null, 400);
        }

        $maxBytes = 5 * 1024 * 1024; // 5MB
        if ($uploaded['size'] > $maxBytes) {
            return Response::error("File exceeds 5MB limit.", "FILE_TOO_LARGE", null, 400);
        }

        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $uploaded['tmp_name']);
        finfo_close($finfo);

        $allowed = [
            'image/png' => 'png',
            'image/jpeg' => 'jpg',
            'image/webp' => 'webp',
            'image/svg+xml' => 'svg',
        ];

        if (!isset($allowed[$mime])) {
            return Response::error("Only PNG, JPG, WebP, or SVG images are allowed.", "INVALID_MIME", null, 400);
        }

        $ext = $allowed[$mime];
        if ($ext === 'svg' && !$this->isSvgSafe($uploaded['tmp_name'])) {
            return Response::error("SVG file contains unsafe scripts or embedded objects.", "UNSAFE_SVG", null, 400);
        }
        $targetDir = realpath(__DIR__ . '/../../public') . '/uploads/workspaces';
        if (!is_dir($targetDir)) {
            @mkdir($targetDir, 0755, true);
        }

        $fileName = 'ws_' . $tenantId . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
        $targetPath = $targetDir . '/' . $fileName;

        $saved = is_uploaded_file($uploaded['tmp_name'])
            ? @move_uploaded_file($uploaded['tmp_name'], $targetPath)
            : @copy($uploaded['tmp_name'], $targetPath);

        if (!$saved) {
            return Response::error("Failed to save workspace logo.", "UPLOAD_FAILED", null, 500);
        }

        $logoUrl = url('/uploads/workspaces/' . $fileName);
        Database::execute("UPDATE tenants SET logo_url = ? WHERE id = ?", [$logoUrl, $tenantId]);

        return Response::success(['logo_url' => $logoUrl], "Workspace logo updated successfully.");
    }

    public function updateProfile(Request $request): Response
    {
        $user = current_user();
        if (!$user) {
            return Response::error("Unauthenticated.", "UNAUTHENTICATED", null, 401);
        }
        $userId = (int)$user['id'];

        $name = trim((string)$request->input('name', ''));
        $email = trim(strtolower((string)$request->input('email', '')));
        $password = (string)$request->input('password', '');

        if (empty($name) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return Response::error("Valid name and email are required.", "VALIDATION_FAILED", null, 400);
        }

        // Check email uniqueness
        $existing = Database::fetchOne("SELECT id FROM users WHERE email = ? AND id != ?", [$email, $userId]);
        if ($existing) {
            return Response::error("Email already in use.", "EMAIL_TAKEN", null, 400);
        }

        $avatarUpdate = '';
        $params = [$name, $email];
        if ($request->input('remove_avatar')) {
            $avatarUpdate = ', avatar_url = NULL';
        } elseif ($request->has('avatar_url')) {
            $avatarUrl = trim((string)$request->input('avatar_url')) ?: null;
            $avatarUpdate = ', avatar_url = ?';
            $params[] = $avatarUrl;
        }

        if (!empty($password)) {
            if (strlen($password) < 6) {
                return Response::error("Password must be at least 6 characters.", "PASSWORD_TOO_SHORT", null, 400);
            }
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $params[] = $hash;
            $params[] = $userId;
            Database::execute("UPDATE users SET name = ?, email = ?{$avatarUpdate}, password_hash = ? WHERE id = ?", $params);
        } else {
            $params[] = $userId;
            Database::execute("UPDATE users SET name = ?, email = ?{$avatarUpdate} WHERE id = ?", $params);
        }

        $updatedUser = Database::fetchOne("SELECT id, name, email, avatar_url, is_platform_admin, status FROM users WHERE id = ?", [$userId]);
        Session::set('user', $updatedUser);

        return Response::success($updatedUser, "Profile updated successfully.");
    }

    public function uploadUserAvatar(Request $request): Response
    {
        $user = current_user();
        if (!$user) {
            return Response::error("Unauthenticated.", "UNAUTHENTICATED", null, 401);
        }
        $userId = (int)$user['id'];

        $uploaded = $_FILES['avatar'] ?? $_FILES['file'] ?? null;
        if (!$uploaded || $uploaded['error'] !== UPLOAD_ERR_OK) {
            return Response::error("No avatar file uploaded or upload error occurred.", "NO_FILE", null, 400);
        }

        $maxBytes = 5 * 1024 * 1024; // 5MB
        if ($uploaded['size'] > $maxBytes) {
            return Response::error("Avatar exceeds 5MB limit.", "FILE_TOO_LARGE", null, 400);
        }

        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $uploaded['tmp_name']);
        finfo_close($finfo);

        $allowed = [
            'image/png' => 'png',
            'image/jpeg' => 'jpg',
            'image/webp' => 'webp',
        ];

        if (!isset($allowed[$mime])) {
            return Response::error("Only PNG, JPG, and WebP images are allowed.", "INVALID_MIME", null, 400);
        }

        $ext = $allowed[$mime];

        // Safe upload directory discovery that works on both cPanel and localhost
        $uploadBaseCandidates = [
            dirname(__DIR__, 2) . '/public/uploads/avatars',
            dirname(__DIR__, 2) . '/uploads/avatars',
            rtrim($_SERVER['DOCUMENT_ROOT'] ?? '', '/\\') . '/uploads/avatars',
            rtrim($_SERVER['DOCUMENT_ROOT'] ?? '', '/\\') . '/public/uploads/avatars',
        ];

        $targetDir = null;
        foreach ($uploadBaseCandidates as $candidate) {
            if (!empty($candidate)) {
                if (!is_dir($candidate)) {
                    @mkdir($candidate, 0775, true);
                }
                if (is_dir($candidate) && is_writable($candidate)) {
                    $targetDir = $candidate;
                    break;
                }
            }
        }

        if (!$targetDir) {
            $targetDir = dirname(__DIR__, 2) . '/public/uploads/avatars';
            if (!is_dir($targetDir)) {
                @mkdir($targetDir, 0775, true);
            }
        }
        @chmod($targetDir, 0775);

        $fileName = 'usr_' . $userId . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
        $targetPath = $targetDir . '/' . $fileName;

        $tmpFile = $uploaded['tmp_name'];
        $saved = false;
        if (is_uploaded_file($tmpFile)) {
            $saved = @move_uploaded_file($tmpFile, $targetPath);
        }
        if (!$saved) {
            $saved = @copy($tmpFile, $targetPath);
        }
        if (!$saved) {
            $content = @file_get_contents($tmpFile);
            if ($content !== false && @file_put_contents($targetPath, $content) !== false) {
                $saved = true;
            }
        }

        if ($saved) {
            @chmod($targetPath, 0664);
            // Also mirror to root /uploads/avatars if different
            $altDir = dirname(__DIR__, 2) . '/uploads/avatars';
            if ($altDir !== $targetDir) {
                if (!is_dir($altDir)) {
                    @mkdir($altDir, 0775, true);
                }
                if (is_dir($altDir)) {
                    @copy($targetPath, $altDir . '/' . $fileName);
                }
            }
        } else {
            $err = error_get_last();
            Logger::error("Failed to save avatar image to {$targetPath}. Error: " . ($err['message'] ?? 'none'));
            return Response::error("Failed to save avatar image. Please check directory permissions on uploads/avatars.", "UPLOAD_FAILED", null, 500);
        }

        $avatarUrl = '/uploads/avatars/' . $fileName;
        Database::execute("UPDATE users SET avatar_url = ? WHERE id = ?", [$avatarUrl, $userId]);

        $updatedUser = Database::fetchOne("SELECT id, name, email, avatar_url, is_platform_admin, status FROM users WHERE id = ?", [$userId]);
        Session::set('user', $updatedUser);

        return Response::success(['avatar_url' => $avatarUrl, 'user' => $updatedUser], "Profile picture updated successfully.");
    }

    // ==========================================
    // PUBLIC QUIZ MANIFEST (FOR VISITOR RUNNER)
    // ==========================================

    public function quizManifest(Request $request, string $slug): Response
    {
        $funnel = Database::fetchOne(
            "SELECT f.id, f.tenant_id, f.name, f.slug, f.description, f.status, f.funnel_mode, f.settings_json, t.name as tenant_name 
             FROM funnels f 
             JOIN tenants t ON f.tenant_id = t.id 
             WHERE f.slug = ? AND f.status = 'published'",
            [$slug]
        );

        if (!$funnel) {
            return Response::error("Quiz not found or not published.", "NOT_FOUND", null, 404);
        }

        $settings = json_decode($funnel['settings_json'] ?? '{}', true) ?: [];

        return Response::success([
            'funnel_id' => (int)$funnel['id'],
            'name' => $funnel['name'],
            'slug' => $funnel['slug'],
            'description' => $funnel['description'],
            'funnel_mode' => $funnel['funnel_mode'] ?? 'quiz',
            'tenant_name' => $funnel['tenant_name'],
            'settings' => [
                'theme' => $settings['theme'] ?? 'light',
                'accent_color' => $settings['accent_color'] ?? '#5B5BD6',
                'company_name' => $settings['company_name'] ?? $funnel['tenant_name'],
                'logo_url' => $settings['logo_url'] ?? '',
                'logo_position' => $settings['logo_position'] ?? 'left',
                'logo_height' => max(24, min(90, (int)($settings['logo_height'] ?? 36))),
                'white_label' => !empty($settings['white_label']),
                'trust_badge_text' => !empty($settings['trust_badge_text']) ? $settings['trust_badge_text'] : '256-Bit SSL Encrypted • 100% Privacy Guaranteed',
                'footer_text' => !empty($settings['footer_text']) ? $settings['footer_text'] : ('© ' . date('Y') . ' ' . ($settings['company_name'] ?? $funnel['tenant_name']) . '. All rights reserved.'),
                'privacy_policy_url' => $settings['privacy_policy_url'] ?? '',
                'terms_url' => $settings['terms_url'] ?? '',
                'show_progress_bar' => !isset($settings['show_progress_bar']) || !empty($settings['show_progress_bar']),
                'card_radius' => $settings['card_radius'] ?? 'rounded-2xl',
                'button_radius' => $settings['button_radius'] ?? 'rounded-xl',
                'button_style' => $settings['button_style'] ?? 'solid',
                'cta_button_text' => $settings['cta_button_text'] ?? '',
                'font_family' => $settings['font_family'] ?? 'sans',
                'background_style' => $settings['background_style'] ?? 'default',
                'card_elevation' => $settings['card_elevation'] ?? 'soft',
                'social_proof_badge' => $settings['social_proof_badge'] ?? '',
                'fb_pixel_id' => $settings['fb_pixel_id'] ?? '',
                'google_tag_id' => $settings['google_tag_id'] ?? '',
                'tiktok_pixel_id' => $settings['tiktok_pixel_id'] ?? '',
                'meta_title' => $settings['meta_title'] ?? '',
                'meta_description' => $settings['meta_description'] ?? '',
            ]
        ]);
    }

    public function quizInit(Request $request, string $slug): Response
    {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        if (!RateLimiterService::check('quiz_init', $ip, 60, 60)) {
            return Response::error("Too many quiz requests from this IP. Please wait a moment before trying again.", 'RATE_LIMIT_EXCEEDED', null, 429);
        }

        $funnel = FunnelService::getPublishedFunnelBySlug($slug);
        if ($funnel && ($funnel['tenant_status'] ?? 'active') === 'suspended') {
            return Response::error("This quiz is temporarily paused by the organizer.", 'QUIZ_PAUSED', null, 503);
        }

        if ($funnel) {
            $quotaCheck = UsageLimitService::checkCanAcceptSubmission((int)$funnel['tenant_id']);
            if (!$quotaCheck['allowed']) {
                return Response::error($quotaCheck['message'], 'LEAD_QUOTA_EXHAUSTED', null, 429);
            }
        }

        try {
            $data = QuizEngineService::initializeSession($slug);
            return Response::success($data);
        } catch (\Throwable $e) {
            return Response::error($e->getMessage(), 'INIT_FAILED', null, 400);
        }
    }

    public function quizStep(Request $request): Response
    {
        $token = $request->header('x-quiz-session') ?? $request->query('session_token');
        if (empty($token)) {
            return Response::error("Missing quiz session token.", "UNAUTHORIZED", null, 401);
        }

        try {
            $step = QuizEngineService::getCurrentStep($token);
            return Response::success($step);
        } catch (\Throwable $e) {
            return Response::error($e->getMessage(), 'STEP_ERROR', null, 400);
        }
    }

    public function quizSubmitForm(Request $request): Response
    {
        $token = $request->header('x-quiz-session') ?? $request->input('session_token');
        if (empty($token)) {
            return Response::error("Missing quiz session token.", "UNAUTHORIZED", null, 401);
        }

        $formData = $request->input('form_data', []);

        try {
            $res = QuizEngineService::submitForm($token, $formData);
            if (isset($res['success']) && $res['success'] === false) {
                return Response::error("Form validation failed", "VALIDATION_FAILED", $res['errors'] ?? [], 422);
            }
            return Response::success($res, 'Form submitted successfully.');
        } catch (\Throwable $e) {
            return Response::error($e->getMessage(), 'FORM_ERROR', null, 400);
        }
    }

    public function quizSubmitAnswer(Request $request): Response
    {
        $token = $request->header('x-quiz-session') ?? $request->input('session_token');
        if (empty($token)) {
            return Response::error("Missing quiz session token.", "UNAUTHORIZED", null, 401);
        }

        $nodeId = (int)$request->input('node_id');
        $answer = $request->input('answer', []);

        try {
            $step = QuizEngineService::submitAnswer($token, $nodeId, $answer);
            return Response::success($step);
        } catch (\Throwable $e) {
            return Response::error($e->getMessage(), 'ANSWER_ERROR', null, 400);
        }
    }

    public function quizBack(Request $request): Response
    {
        $token = $request->header('x-quiz-session') ?? $request->input('session_token');
        if (empty($token)) {
            return Response::error("Missing quiz session token.", "UNAUTHORIZED", null, 401);
        }

        try {
            $step = QuizEngineService::navigateBack($token);
            return Response::success($step);
        } catch (\Throwable $e) {
            return Response::error($e->getMessage(), 'BACK_ERROR', null, 400);
        }
    }

    public function quizVideoEvent(Request $request): Response
    {
        $token = $request->header('x-quiz-session') ?? $request->input('session_token');
        if (empty($token)) {
            return Response::error("Missing quiz session token.", "UNAUTHORIZED", null, 401);
        }

        $nodeId = (int)$request->input('node_id');
        $eventType = (string)$request->input('event_type');
        $eventData = $request->input('event_data', []);

        try {
            $res = QuizEngineService::recordVideoEvent($token, $nodeId, $eventType, $eventData);
            return Response::success($res);
        } catch (\Throwable $e) {
            return Response::error($e->getMessage(), 'VIDEO_EVENT_ERROR', null, 400);
        }
    }

    public function quizSubmitVideoGate(Request $request): Response
    {
        $token = $request->header('x-quiz-session') ?? $request->input('session_token');
        if (empty($token)) {
            return Response::error("Missing quiz session token.", "UNAUTHORIZED", null, 401);
        }

        $nodeId = (int)$request->input('node_id');
        $payload = $request->all();

        try {
            $res = QuizEngineService::submitVideoGate($token, $nodeId, $payload);
            if (isset($res['success']) && $res['success'] === false) {
                return Response::error($res['error'] ?? 'Validation failed', 'VALIDATION_FAILED', $res['errors'] ?? [], 422);
            }
            return Response::success($res);
        } catch (\Throwable $e) {
            return Response::error($e->getMessage(), 'VIDEO_GATE_ERROR', null, 400);
        }
    }

    public function quizVideoAdvance(Request $request): Response
    {
        $token = $request->header('x-quiz-session') ?? $request->input('session_token');
        if (empty($token)) {
            return Response::error("Missing quiz session token.", "UNAUTHORIZED", null, 401);
        }

        $nodeId = (int)$request->input('node_id');

        try {
            $step = QuizEngineService::advanceVideoStep($token, $nodeId);
            return Response::success($step);
        } catch (\Throwable $e) {
            return Response::error($e->getMessage(), 'VIDEO_ADVANCE_ERROR', null, 400);
        }
    }

    // ==========================================
    // SUPER ADMIN PLATFORM
    // ==========================================

    public function superadminDashboard(Request $request): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        // Automated fallback check: Evaluates billing cycles if 24h elapsed without server cron
        SubscriptionService::checkAndRunDailyEvaluationFallback();

        $totalTenants = (int) Database::fetchColumn("SELECT COUNT(*) FROM tenants WHERE status != 'deleted'");
        $activeTenants = (int) Database::fetchColumn("SELECT COUNT(*) FROM tenants WHERE status = 'active'");
        $suspendedTenants = (int) Database::fetchColumn("SELECT COUNT(*) FROM tenants WHERE status = 'suspended'");
        $terminationDueCount = count(SubscriptionService::getTerminationDueWorkspaces());

        $totalUsers = (int) Database::fetchColumn("SELECT COUNT(*) FROM users");
        $activeUsers = (int) Database::fetchColumn("SELECT COUNT(*) FROM users WHERE status = 'active'");

        $totalFunnels = (int) Database::fetchColumn("SELECT COUNT(*) FROM funnels WHERE status != 'archived'");
        $publishedFunnels = (int) Database::fetchColumn("SELECT COUNT(*) FROM funnels WHERE status = 'published'");
        $totalSubmissions = (int) Database::fetchColumn("SELECT COUNT(*) FROM quiz_sessions");
        if ($totalSubmissions === 0) {
            $totalSubmissions = (int) Database::fetchColumn("SELECT COUNT(*) FROM form_submissions");
        }

        // Plan distribution
        $planStats = Database::query(
            "SELECT p.id, p.name, p.slug, p.price, COUNT(ts.id) as subscriber_count
             FROM plans p
             LEFT JOIN tenant_subscriptions ts ON ts.plan_id = p.id AND ts.status IN ('active', 'trial')
             GROUP BY p.id, p.name, p.slug, p.price
             ORDER BY p.price ASC, p.id ASC"
        );

        // Recent Workspaces
        $recentTenants = Database::query(
            "SELECT t.*, 
                    (SELECT COUNT(*) FROM funnels f WHERE f.tenant_id = t.id AND f.status != 'archived') as funnels_count,
                    (SELECT u.name FROM tenant_memberships tm JOIN users u ON tm.user_id = u.id WHERE tm.tenant_id = t.id AND tm.role = 'owner' LIMIT 1) as owner_name,
                    p.name as plan_name
             FROM tenants t
             LEFT JOIN tenant_subscriptions ts ON ts.tenant_id = t.id AND ts.status IN ('active', 'trial')
             LEFT JOIN plans p ON ts.plan_id = p.id
             WHERE t.status != 'deleted'
             ORDER BY t.created_at DESC
             LIMIT 6"
        );

        $recentLogs = Database::query(
            "SELECT al.*, u.name as user_name, u.email as user_email, t.name as tenant_name 
             FROM audit_logs al
             LEFT JOIN users u ON al.user_id = u.id
             LEFT JOIN tenants t ON al.tenant_id = t.id
             ORDER BY al.id DESC LIMIT 10"
        );

        // Gateways count
        $gateways = PlatformSettingService::getPaymentGateways();
        $activeGatewaysCount = 0;
        foreach ($gateways as $gw) {
            if (!empty($gw['enabled'])) {
                $activeGatewaysCount++;
            }
        }

        return Response::success([
            'stats' => [
                'total_tenants' => $totalTenants,
                'active_tenants' => $activeTenants,
                'suspended_tenants' => $suspendedTenants,
                'termination_due_count' => $terminationDueCount,
                'total_users' => $totalUsers,
                'active_users' => $activeUsers,
                'total_funnels' => $totalFunnels,
                'published_funnels' => $publishedFunnels,
                'total_submissions' => $totalSubmissions,
                'active_gateways_count' => $activeGatewaysCount,
            ],
            'plan_stats' => $planStats,
            'recent_tenants' => $recentTenants,
            'recent_logs' => $recentLogs,
            'system_info' => [
                'php_version' => PHP_VERSION,
                'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'PHP CLI / Web Server',
                'db_driver' => 'MySQL / MariaDB via PDO',
                'max_upload' => ini_get('upload_max_filesize'),
                'timezone' => date_default_timezone_get(),
            ]
        ]);
    }

    public function superadminCustomers(Request $request): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $customers = Database::query(
            "SELECT t.*, 
                    (SELECT COUNT(*) FROM funnels f WHERE f.tenant_id = t.id AND f.status != 'archived') as funnels_count,
                    (SELECT COUNT(*) FROM quiz_sessions qs WHERE qs.tenant_id = t.id) as sessions_count,
                    (SELECT u.id FROM tenant_memberships tm JOIN users u ON tm.user_id = u.id WHERE tm.tenant_id = t.id AND tm.role = 'owner' LIMIT 1) as owner_id,
                    (SELECT u.name FROM tenant_memberships tm JOIN users u ON tm.user_id = u.id WHERE tm.tenant_id = t.id AND tm.role = 'owner' LIMIT 1) as owner_name,
                    (SELECT u.email FROM tenant_memberships tm JOIN users u ON tm.user_id = u.id WHERE tm.tenant_id = t.id AND tm.role = 'owner' LIMIT 1) as owner_email,
                    p.id as current_plan_id,
                    p.name as plan_name,
                    p.slug as plan_slug,
                    p.price as plan_price,
                    ts.id as subscription_id,
                    ts.status as subscription_status,
                    ts.billing_interval,
                    ts.current_period_start,
                    ts.current_period_end,
                    ts.next_billing_date,
                    ts.ends_at as subscription_ends_at,
                    ts.auto_renew,
                    ts.amount as subscription_amount,
                    ts.currency as subscription_currency
             FROM tenants t
             LEFT JOIN tenant_subscriptions ts ON ts.tenant_id = t.id AND ts.id = (SELECT MAX(id) FROM tenant_subscriptions WHERE tenant_id = t.id)
             LEFT JOIN plans p ON ts.plan_id = p.id
             WHERE t.status != 'deleted'
             ORDER BY t.created_at DESC"
        );

        $terminationDueList = SubscriptionService::getTerminationDueWorkspaces();
        $invoices = SubscriptionService::getAllInvoices(50);

        $users = Database::query(
            "SELECT u.*, 
                    (SELECT COUNT(*) FROM tenant_memberships tm WHERE tm.user_id = u.id) as workspace_count,
                    (SELECT GROUP_CONCAT(t.name SEPARATOR ', ') FROM tenant_memberships tm JOIN tenants t ON tm.tenant_id = t.id WHERE tm.user_id = u.id) as workspace_names
             FROM users u
             ORDER BY u.created_at DESC
             LIMIT 100"
        );

        $plans = Database::query("SELECT id, name, slug, price, billing_interval FROM plans WHERE is_active = 1 ORDER BY price ASC, id ASC");

        $defaultCronKey = PlatformSettingService::get('cron_secret_key');
        if (empty($defaultCronKey)) {
            $defaultCronKey = 'lc_cron_' . bin2hex(random_bytes(8));
            PlatformSettingService::set('cron_secret_key', $defaultCronKey);
        }

        $cronFilePath = realpath(__DIR__ . '/../../cron.php') ?: (realpath(__DIR__ . '/../../database/billing_cron.php') ?: 'cron.php');
        $cronInfo = [
            'last_evaluation_at' => PlatformSettingService::get('last_billing_evaluation_at'),
            'last_evaluation_result' => PlatformSettingService::get('last_billing_evaluation_result'),
            'cron_secret_key' => $defaultCronKey,
            'cli_command' => '0 0 * * * /usr/local/bin/php ' . $cronFilePath . ' >/dev/null 2>&1',
            'web_cron_url' => url('/api/cron/billing?key=' . $defaultCronKey),
        ];

        return Response::success([
            'customers' => $customers,
            'termination_due_list' => $terminationDueList,
            'invoices' => $invoices,
            'users' => $users,
            'plans' => $plans,
            'cron_info' => $cronInfo,
        ]);
    }

    public function superadminToggleTenant(Request $request, string $id): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $tenant = Database::fetchOne("SELECT * FROM tenants WHERE id = ?", [(int)$id]);
        if (!$tenant) {
            return Response::error("Tenant workspace not found.", "NOT_FOUND", null, 404);
        }

        $newStatus = $tenant['status'] === 'active' ? 'suspended' : 'active';
        Database::execute("UPDATE tenants SET status = ? WHERE id = ?", [$newStatus, $tenant['id']]);

        $currentUser = current_user();
        AuditLogService::log($tenant['id'], (int)($currentUser['id'] ?? 0), 'toggle_tenant_status', 'tenant', $tenant['id'], [
            'previous_status' => $tenant['status'],
            'new_status' => $newStatus
        ]);

        return Response::success([
            'tenant_id' => $tenant['id'],
            'new_status' => $newStatus,
        ], "Workspace '{$tenant['name']}' has been " . ($newStatus === 'active' ? 'reactivated.' : 'suspended.'));
    }

    public function superadminAssignPlan(Request $request, string $id): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $tenantId = (int)$id;
        $planId = (int)$request->input('plan_id');
        $status = (string)$request->input('status', 'active');

        $tenant = Database::fetchOne("SELECT * FROM tenants WHERE id = ?", [$tenantId]);
        $plan = Database::fetchOne("SELECT * FROM plans WHERE id = ?", [$planId]);

        if (!$tenant || !$plan) {
            return Response::error("Invalid tenant workspace or plan selected.", "VALIDATION_FAILED", null, 400);
        }

        // Deactivate previous active subscriptions
        Database::execute("UPDATE tenant_subscriptions SET status = 'cancelled' WHERE tenant_id = ? AND status IN ('active', 'trial')", [$tenantId]);

        $currentUser = current_user();
        Database::execute(
            "INSERT INTO tenant_subscriptions (tenant_id, plan_id, status, starts_at, ends_at, provider, provider_subscription_id) 
             VALUES (?, ?, ?, NOW(), DATE_ADD(NOW(), INTERVAL 1 YEAR), 'manual_superadmin', ?)",
            [$tenantId, $planId, $status, 'assigned_by_admin_' . ($currentUser['id'] ?? 1)]
        );

        AuditLogService::log($tenantId, (int)($currentUser['id'] ?? 0), 'assign_plan', 'tenant', $tenantId, [
            'plan_id' => $planId,
            'plan_name' => $plan['name'],
            'status' => $status
        ]);

        return Response::success([
            'tenant_id' => $tenantId,
            'plan_name' => $plan['name'],
            'status' => $status,
        ], "Assigned plan '{$plan['name']}' to workspace '{$tenant['name']}'.");
    }

    public function superadminBillingCycle(Request $request, string $id): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $tenantId = (int)$id;
        $adminUserId = (int)(current_user()['id'] ?? 1);

        try {
            SubscriptionService::modifyBillingCycle($tenantId, [
                'plan_id' => (int)$request->input('plan_id'),
                'billing_interval' => (string)$request->input('billing_interval', 'monthly'),
                'current_period_start' => (string)$request->input('current_period_start'),
                'current_period_end' => (string)$request->input('current_period_end'),
                'status' => (string)$request->input('status', 'active'),
                'auto_renew' => !empty($request->input('auto_renew')),
                'amount' => (float)$request->input('amount', 0),
                'currency' => (string)$request->input('currency', 'INR'),
            ], $adminUserId);

            return Response::success(null, "Billing cycle and subscription terms successfully updated.");
        } catch (\Throwable $e) {
            return Response::error("Failed to update billing cycle: " . $e->getMessage(), "ERROR", null, 400);
        }
    }

    public function superadminRecordPayment(Request $request, string $id): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $tenantId = (int)$id;
        $adminUserId = (int)(current_user()['id'] ?? 1);

        try {
            $invoice = SubscriptionService::recordManualPayment($tenantId, [
                'plan_id' => (int)$request->input('plan_id'),
                'amount' => (float)$request->input('amount', 0),
                'currency' => (string)$request->input('currency', 'INR'),
                'billing_interval' => (string)$request->input('billing_interval', 'monthly'),
                'payment_method' => (string)$request->input('payment_method', 'bank_transfer'),
                'transaction_reference' => (string)$request->input('transaction_reference', ''),
                'notes' => (string)$request->input('notes', ''),
            ], $adminUserId);

            return Response::success($invoice, "Payment recorded! Invoice #{$invoice['invoice_number']} generated and billing cycle extended.");
        } catch (\Throwable $e) {
            return Response::error("Failed to record payment: " . $e->getMessage(), "ERROR", null, 400);
        }
    }

    public function superadminSuspendTenant(Request $request, string $id): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $tenantId = (int)$id;
        $adminUserId = (int)(current_user()['id'] ?? 1);
        $reason = trim((string)$request->input('reason', 'Overdue subscription payment'));
        $notes = trim((string)$request->input('notes', ''));

        try {
            SubscriptionService::suspendWorkspace($tenantId, $reason, $notes, $adminUserId);
            return Response::success(null, "Workspace suspended. All customer funnels and lead data remain 100% securely preserved.");
        } catch (\Throwable $e) {
            return Response::error("Failed to suspend workspace: " . $e->getMessage(), "ERROR", null, 400);
        }
    }

    public function superadminUnsuspendTenant(Request $request, string $id): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $tenantId = (int)$id;
        $adminUserId = (int)(current_user()['id'] ?? 1);
        $extendUntil = trim((string)$request->input('extend_until', ''));

        try {
            SubscriptionService::unsuspendWorkspace($tenantId, !empty($extendUntil) ? $extendUntil : null, $adminUserId);
            return Response::success(null, "Workspace successfully reactivated! Normal service resumed.");
        } catch (\Throwable $e) {
            return Response::error("Failed to unsuspend workspace: " . $e->getMessage(), "ERROR", null, 400);
        }
    }

    public function superadminMarkTerminationDue(Request $request, string $id): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $tenantId = (int)$id;
        $adminUserId = (int)(current_user()['id'] ?? 1);
        $reason = trim((string)$request->input('reason', 'Account marked for termination review'));

        try {
            SubscriptionService::markTerminationDue($tenantId, $reason, $adminUserId);
            return Response::success(null, "Workspace added to Termination Due review queue.");
        } catch (\Throwable $e) {
            return Response::error("Error: " . $e->getMessage(), "ERROR", null, 400);
        }
    }

    public function superadminDismissTerminationDue(Request $request, string $id): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $tenantId = (int)$id;
        $adminUserId = (int)(current_user()['id'] ?? 1);

        try {
            SubscriptionService::dismissTerminationDue($tenantId, $adminUserId);
            return Response::success(null, "Workspace dismissed from Termination Due queue.");
        } catch (\Throwable $e) {
            return Response::error("Error: " . $e->getMessage(), "ERROR", null, 400);
        }
    }

    public function superadminTerminateTenant(Request $request, string $id): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $tenantId = (int)$id;
        $adminUserId = (int)(current_user()['id'] ?? 1);
        $confirmSlug = trim((string)$request->input('confirm_slug', ''));
        $reason = trim((string)$request->input('reason', 'Administrative manual contract termination'));

        $tenant = Database::fetchOne("SELECT * FROM tenants WHERE id = ?", [$tenantId]);
        if (!$tenant) {
            return Response::error("Workspace not found.", "NOT_FOUND", null, 404);
        }

        if (strtolower($confirmSlug) !== strtolower($tenant['slug'])) {
            return Response::error("Confirmation failed: You must type '{$tenant['slug']}' to confirm manual termination.", "VALIDATION_FAILED", null, 400);
        }

        try {
            SubscriptionService::terminateWorkspace($tenantId, $reason, $adminUserId);
            return Response::success(null, "Workspace '{$tenant['name']}' has been manually terminated. Historical data is archived.");
        } catch (\Throwable $e) {
            return Response::error("Failed to terminate workspace: " . $e->getMessage(), "ERROR", null, 400);
        }
    }

    public function superadminEvaluateBilling(Request $request): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $result = SubscriptionService::runBillingCycleEvaluation();
        $adminUserId = (int)(current_user()['id'] ?? 1);
        AuditLogService::log(null, $adminUserId, 'manual_billing_evaluation', 'platform', 0, $result);

        return Response::success($result, "Billing cycle evaluation completed successfully.");
    }

    public function cronBillingEvaluation(Request $request): Response
    {
        $configuredKey = (string)(\App\Core\Env::get('CRON_SECRET') ?: PlatformSettingService::get('cron_secret_key', ''));

        $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        $providedKey = '';
        if (preg_match('/Bearer\s+(\S+)/i', $authHeader, $matches)) {
            $providedKey = $matches[1];
        } elseif (!empty($_SERVER['HTTP_X_CRON_KEY'])) {
            $providedKey = (string)$_SERVER['HTTP_X_CRON_KEY'];
        } else {
            $providedKey = (string)$request->query('key', $request->input('key', ''));
        }

        if (!empty($configuredKey)) {
            if (empty($providedKey) || !hash_equals($configuredKey, $providedKey)) {
                return Response::error("Invalid or missing cron security key.", "UNAUTHORIZED", null, 403);
            }
        } elseif (!empty($providedKey)) {
            $validDefaults = ['filterfunnel_cron_secret', 'leadcollector_cron_secret'];
            $matched = false;
            foreach ($validDefaults as $def) {
                if (hash_equals($def, $providedKey)) {
                    $matched = true;
                    break;
                }
            }
            if (!$matched) {
                return Response::error("Invalid cron security key.", "UNAUTHORIZED", null, 403);
            }
        }

        $result = SubscriptionService::runBillingCycleEvaluation();
        return Response::success($result, "Cron billing cycle evaluation completed successfully.");
    }

    public function superadminToggleUserStatus(Request $request, string $id): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $userId = (int)$id;
        $currentUser = current_user();

        if ($userId === (int)($currentUser['id'] ?? 0)) {
            return Response::error("You cannot suspend your own administrative account.", "ACTION_NOT_ALLOWED", null, 400);
        }

        $targetUser = Database::fetchOne("SELECT * FROM users WHERE id = ?", [$userId]);
        if (!$targetUser) {
            return Response::error("Target user not found.", "NOT_FOUND", null, 404);
        }

        $newStatus = ($targetUser['status'] === 'active') ? 'suspended' : 'active';
        Database::execute("UPDATE users SET status = ? WHERE id = ?", [$newStatus, $userId]);

        AuditLogService::log(null, (int)$currentUser['id'], 'toggle_user_status', 'user', $userId, [
            'user_email' => $targetUser['email'],
            'new_status' => $newStatus
        ]);

        return Response::success([
            'user_id' => $userId,
            'new_status' => $newStatus,
        ], "User '{$targetUser['name']}' ({$targetUser['email']}) is now " . ($newStatus === 'active' ? 'active.' : 'suspended.'));
    }

    public function superadminPlans(Request $request): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $plans = Database::query(
            "SELECT p.*, 
                    (SELECT COUNT(*) FROM tenant_subscriptions ts WHERE ts.plan_id = p.id AND ts.status IN ('active', 'trial')) as active_subscribers_count
             FROM plans p
             ORDER BY p.price ASC, p.id ASC"
        );
        $featureCatalog = UsageLimitService::getFeatureCatalog();

        return Response::success([
            'plans' => $plans,
            'feature_catalog' => $featureCatalog,
        ]);
    }

    public function superadminCreatePlan(Request $request): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $name = trim((string)$request->input('name', ''));
        $slug = trim((string)$request->input('slug', ''));
        $price = (float)$request->input('price', 0);
        $interval = (string)$request->input('billing_interval', 'monthly');
        $description = trim((string)$request->input('description', ''));

        $maxFunnels = (int)$request->input('max_funnels', 1);
        $maxSubmissions = (int)$request->input('max_submissions_per_month', 100);
        $maxTeamMembers = (int)$request->input('max_team_members', 1);

        if (empty($name)) {
            return Response::error("Plan name is required.", "VALIDATION_FAILED", null, 400);
        }

        if (empty($slug)) {
            $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $name));
            $slug = trim($slug, '-');
        }

        $existing = Database::fetchOne("SELECT id FROM plans WHERE slug = ?", [$slug]);
        if ($existing) {
            return Response::error("A plan with slug '{$slug}' already exists.", "SLUG_TAKEN", null, 400);
        }

        $limits = [
            'max_funnels' => $maxFunnels,
            'max_submissions_per_month' => $maxSubmissions,
            'max_team_members' => $maxTeamMembers,
        ];

        // Features catalog flags
        $catalog = UsageLimitService::getFeatureCatalog();
        $features = [];
        $inputFeatures = $request->input('features');
        if (is_array($inputFeatures)) {
            foreach ($catalog as $key => $meta) {
                $features[$key] = !empty($inputFeatures[$key]);
            }
        } else {
            foreach ($catalog as $key => $meta) {
                $features[$key] = !empty($request->input("feature_{$key}"));
            }
        }

        Database::execute(
            "INSERT INTO plans (name, slug, price, billing_interval, description, limits_json, features_json, is_active, is_visible) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [
                $name,
                $slug,
                $price,
                $interval,
                $description,
                json_encode($limits),
                json_encode($features),
                !empty($request->input('is_active', 1)) ? 1 : 0,
                !empty($request->input('is_visible', 1)) ? 1 : 0
            ]
        );

        $newPlanId = (int)Database::lastInsertId();
        $currentUser = current_user();
        AuditLogService::log(null, (int)($currentUser['id'] ?? 0), 'create_plan', 'plan', $newPlanId, ['name' => $name, 'slug' => $slug]);

        return Response::success(['id' => $newPlanId, 'name' => $name, 'slug' => $slug], "Plan '{$name}' created successfully.");
    }

    public function superadminUpdatePlan(Request $request, string $id): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $planId = (int)$id;
        $plan = Database::fetchOne("SELECT * FROM plans WHERE id = ?", [$planId]);
        if (!$plan) {
            return Response::error("Plan not found.", "NOT_FOUND", null, 404);
        }

        $name = trim((string)$request->input('name', ''));
        $price = (float)$request->input('price', 0);
        $interval = (string)$request->input('billing_interval', 'monthly');
        $description = trim((string)$request->input('description', ''));

        $maxFunnels = (int)$request->input('max_funnels', 1);
        $maxSubmissions = (int)$request->input('max_submissions_per_month', 100);
        $maxTeamMembers = (int)$request->input('max_team_members', 1);

        if (empty($name)) {
            return Response::error("Plan name cannot be empty.", "VALIDATION_FAILED", null, 400);
        }

        $limits = [
            'max_funnels' => $maxFunnels,
            'max_submissions_per_month' => $maxSubmissions,
            'max_team_members' => $maxTeamMembers,
        ];

        $catalog = UsageLimitService::getFeatureCatalog();
        $features = [];
        $inputFeatures = $request->input('features');
        if (is_array($inputFeatures)) {
            foreach ($catalog as $key => $meta) {
                $features[$key] = !empty($inputFeatures[$key]);
            }
        } else {
            foreach ($catalog as $key => $meta) {
                $features[$key] = !empty($request->input("feature_{$key}"));
            }
        }

        Database::execute(
            "UPDATE plans SET name = ?, price = ?, billing_interval = ?, description = ?, limits_json = ?, features_json = ?, is_active = ?, is_visible = ? WHERE id = ?",
            [
                $name,
                $price,
                $interval,
                $description,
                json_encode($limits),
                json_encode($features),
                !empty($request->input('is_active', 1)) ? 1 : 0,
                !empty($request->input('is_visible', 1)) ? 1 : 0,
                $planId
            ]
        );

        $currentUser = current_user();
        AuditLogService::log(null, (int)($currentUser['id'] ?? 0), 'update_plan', 'plan', $planId, ['name' => $name]);

        return Response::success(['id' => $planId, 'name' => $name], "Plan '{$name}' updated successfully.");
    }

    public function superadminTogglePlanVisibility(Request $request, string $id): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $planId = (int)$id;
        $plan = Database::fetchOne("SELECT * FROM plans WHERE id = ?", [$planId]);
        if (!$plan) {
            return Response::error("Plan not found.", "NOT_FOUND", null, 404);
        }

        $newVal = empty($plan['is_visible']) ? 1 : 0;
        Database::execute("UPDATE plans SET is_visible = ? WHERE id = ?", [$newVal, $planId]);

        $currentUser = current_user();
        AuditLogService::log(null, (int)($currentUser['id'] ?? 0), 'toggle_plan_visibility', 'plan', $planId, [
            'name' => $plan['name'],
            'is_visible' => $newVal,
        ]);

        return Response::success([
            'id' => $planId,
            'is_visible' => $newVal,
        ], $newVal ? "Plan '{$plan['name']}' is now visible on pricing page." : "Plan '{$plan['name']}' is now hidden from pricing page.");
    }

    public function superadminDeletePlan(Request $request, string $id): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $planId = (int)$id;
        $plan = Database::fetchOne("SELECT * FROM plans WHERE id = ?", [$planId]);
        if (!$plan) {
            return Response::error("Plan not found.", "NOT_FOUND", null, 404);
        }

        $activeSubCount = (int)Database::fetchColumn(
            "SELECT COUNT(*) FROM tenant_subscriptions WHERE plan_id = ? AND status IN ('active', 'trial')",
            [$planId]
        );

        if ($activeSubCount > 0) {
            Database::execute("UPDATE plans SET is_active = 0 WHERE id = ?", [$planId]);
            return Response::success([
                'id' => $planId,
                'is_active' => 0,
            ], "Plan '{$plan['name']}' has {$activeSubCount} active subscriptions and has been deactivated instead of deleted.");
        }

        Database::execute("DELETE FROM plans WHERE id = ?", [$planId]);
        $currentUser = current_user();
        AuditLogService::log(null, (int)($currentUser['id'] ?? 0), 'delete_plan', 'plan', $planId, ['name' => $plan['name']]);

        return Response::success(['id' => $planId], "Plan '{$plan['name']}' was permanently removed.");
    }

    public function superadminPaymentGateways(Request $request): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        if ($request->isMethod('POST')) {
            $payload = [
                'stripe' => [
                    'enabled' => !empty($request->input('stripe_enabled')),
                    'mode' => (string)$request->input('stripe_mode', 'test'),
                    'publishable_key' => trim((string)$request->input('stripe_publishable_key', '')),
                    'secret_key' => trim((string)$request->input('stripe_secret_key', '')),
                    'webhook_secret' => trim((string)$request->input('stripe_webhook_secret', '')),
                ],
                'paypal' => [
                    'enabled' => !empty($request->input('paypal_enabled')),
                    'mode' => (string)$request->input('paypal_mode', 'sandbox'),
                    'client_id' => trim((string)$request->input('paypal_client_id', '')),
                    'client_secret' => trim((string)$request->input('paypal_client_secret', '')),
                ],
                'razorpay' => [
                    'enabled' => !empty($request->input('razorpay_enabled')),
                    'key_id' => trim((string)$request->input('razorpay_key_id', '')),
                    'key_secret' => trim((string)$request->input('razorpay_key_secret', '')),
                ],
                'cashfree' => [
                    'enabled' => !empty($request->input('cashfree_enabled')),
                    'mode' => (string)$request->input('cashfree_mode', 'sandbox'),
                    'app_id' => trim((string)$request->input('cashfree_app_id', '')),
                    'secret_key' => trim((string)$request->input('cashfree_secret_key', '')),
                    'api_version' => '2023-08-01',
                ],
                'bank_transfer' => [
                    'enabled' => !empty($request->input('bank_enabled')),
                    'bank_name' => trim((string)$request->input('bank_name', '')),
                    'account_holder' => trim((string)$request->input('bank_account_holder', '')),
                    'account_number' => trim((string)$request->input('bank_account_number', '')),
                    'routing_code' => trim((string)$request->input('bank_routing_code', '')),
                    'instructions' => trim((string)$request->input('bank_instructions', '')),
                ],
                'manual_custom' => [
                    'enabled' => !empty($request->input('manual_enabled')),
                    'title' => trim((string)$request->input('manual_title', 'Offline / Cash / Cheque Payment')),
                    'instructions' => trim((string)$request->input('manual_instructions', '')),
                    'qr_code_url' => trim((string)$request->input('manual_qr_code_url', '')),
                ],
            ];

            $warnings = [];
            if (!empty($payload['stripe']['enabled']) && (empty($payload['stripe']['publishable_key']) || empty($payload['stripe']['secret_key']))) {
                $warnings[] = "Stripe is enabled with missing keys.";
            }
            if (!empty($payload['razorpay']['enabled']) && (empty($payload['razorpay']['key_id']) || empty($payload['razorpay']['key_secret']))) {
                $warnings[] = "Razorpay is enabled without complete credentials.";
            }
            if (!empty($payload['cashfree']['enabled']) && (empty($payload['cashfree']['app_id']) || empty($payload['cashfree']['secret_key']))) {
                $warnings[] = "Cashfree is enabled without complete App ID or Secret Key.";
            }
            if (!empty($payload['paypal']['enabled']) && empty($payload['paypal']['client_id'])) {
                $warnings[] = "PayPal is enabled without Client ID.";
            }
            if (!empty($payload['bank_transfer']['enabled']) && empty($payload['bank_transfer']['account_number'])) {
                $warnings[] = "Bank Transfer is enabled without account number.";
            }

            PlatformSettingService::set('payment_gateways', $payload);

            $currentUser = current_user();
            AuditLogService::log(null, (int)($currentUser['id'] ?? 0), 'update_payment_gateways', 'settings', null, [
                'stripe_enabled' => $payload['stripe']['enabled'],
                'paypal_enabled' => $payload['paypal']['enabled'],
                'razorpay_enabled' => $payload['razorpay']['enabled'],
                'bank_enabled' => $payload['bank_transfer']['enabled'],
                'manual_enabled' => $payload['manual_custom']['enabled'],
            ]);

            $msg = !empty($warnings)
                ? "Saved with warnings: " . implode(" ", $warnings)
                : "Payment gateway settings successfully updated.";

            return Response::success(['gateways' => $payload, 'warnings' => $warnings], $msg);
        }

        $gateways = PlatformSettingService::getPaymentGateways();
        return Response::success(['gateways' => $gateways]);
    }

    public function superadminUploadGatewayQr(Request $request): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        try {
            $uploadedFile = $request->file('qr_file') ?? $request->file('file') ?? $request->file('image');
            if (!$uploadedFile || $uploadedFile['error'] !== UPLOAD_ERR_OK) {
                return Response::error("Please select a valid image file to upload.", "NO_FILE", null, 400);
            }

            $allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml'];
            $mimeType = null;
            if (function_exists('finfo_open')) {
                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                if ($finfo) {
                    $mimeType = finfo_file($finfo, $uploadedFile['tmp_name']);
                    if (\PHP_VERSION_ID < 80100) {
                        finfo_close($finfo);
                    }
                }
            }
            if (!$mimeType && function_exists('mime_content_type')) {
                $mimeType = mime_content_type($uploadedFile['tmp_name']);
            }

            if (!in_array($mimeType, $allowedTypes, true)) {
                return Response::error("Invalid file format. Allowed types: PNG, JPG, WebP, SVG.", "INVALID_FORMAT", null, 400);
            }

            if ($uploadedFile['size'] > 5 * 1024 * 1024) {
                return Response::error("QR code file size must be less than 5MB.", "FILE_TOO_LARGE", null, 400);
            }

            $mimeToExt = [
                'image/jpeg' => 'jpg',
                'image/png' => 'png',
                'image/webp' => 'webp',
                'image/svg+xml' => 'svg',
            ];
            $cleanExt = $mimeToExt[$mimeType] ?? 'png';

            if ($cleanExt === 'svg' && !$this->isSvgSafe($uploadedFile['tmp_name'])) {
                return Response::error("SVG file contains unsafe scripts or embedded objects.", "UNSAFE_SVG", null, 400);
            }

            $fileName = 'qr_payment_' . bin2hex(random_bytes(6)) . '.' . $cleanExt;
            $targetDir = dirname(__DIR__, 2) . '/public/uploads/gateways';
            if (!is_dir($targetDir)) {
                @mkdir($targetDir, 0755, true);
            }

            $targetPath = $targetDir . '/' . $fileName;
            $saved = is_uploaded_file($uploadedFile['tmp_name'])
                ? @move_uploaded_file($uploadedFile['tmp_name'], $targetPath)
                : @copy($uploadedFile['tmp_name'], $targetPath);

            if (!$saved) {
                return Response::error("Failed to save uploaded QR code file.", "UPLOAD_SAVE_FAILED", null, 500);
            }

            $qrUrl = url('/uploads/gateways/' . $fileName);

            return Response::success([
                'qr_code_url' => $qrUrl,
                'file_name' => $fileName,
            ], "QR code image uploaded successfully.");
        } catch (\Throwable $e) {
            return Response::error($e->getMessage(), "UPLOAD_FAILED", null, 400);
        }
    }

    // ==========================================
    // Public Pricing Plans API
    // ==========================================

    public function publicPlans(Request $request): Response
    {
        $plans = Database::query(
            "SELECT id, name, slug, description, price, billing_interval, limits_json, features_json, is_active, is_visible 
             FROM plans 
             WHERE is_active = 1 AND is_visible = 1 
             ORDER BY price ASC, id ASC"
        );

        $featureCatalog = UsageLimitService::getFeatureCatalog();

        return Response::success([
            'plans' => $plans,
            'feature_catalog' => $featureCatalog,
        ]);
    }

    // ==========================================
    // Public Legal & Company CMS Pages
    // ==========================================

    public function publicLegalPages(Request $request): Response
    {
        $pages = LegalPageService::getPublishedPages();
        return Response::success(['pages' => $pages]);
    }

    public function publicLegalPageDetail(Request $request, string $slug): Response
    {
        $page = LegalPageService::getPageBySlug($slug, true);
        if (!$page) {
            return Response::error("Legal page not found.", "NOT_FOUND", null, 404);
        }
        return Response::success(['page' => $page]);
    }

    public function superadminLegalPages(Request $request): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $pages = LegalPageService::getAllPages();
        return Response::success(['pages' => $pages]);
    }

    public function superadminCreateLegalPage(Request $request): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $title = trim((string)$request->input('title', ''));
        $slug = trim((string)$request->input('slug', ''));
        $metaDescription = trim((string)$request->input('meta_description', ''));
        $content = (string)$request->input('content', '');
        $isPublished = !empty($request->input('is_published', 1)) ? 1 : 0;

        if (empty($title)) {
            return Response::error("Page title is required.", "VALIDATION_FAILED", null, 400);
        }

        try {
            $newPageId = LegalPageService::createPage([
                'title' => $title,
                'slug' => $slug,
                'meta_description' => $metaDescription,
                'content' => $content,
                'is_published' => $isPublished,
            ]);

            $currentUser = current_user();
            AuditLogService::log(null, (int)($currentUser['id'] ?? 0), 'create_legal_page', 'legal_page', $newPageId, [
                'title' => $title,
                'slug' => $slug,
            ]);

            return Response::success(['id' => $newPageId], "New legal page created successfully.");
        } catch (\Throwable $e) {
            return Response::error("Failed to create legal page: " . $e->getMessage(), "ERROR", null, 400);
        }
    }

    public function superadminUpdateLegalPage(Request $request, string $id): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $pageId = (int)$id;

        try {
            LegalPageService::updatePage($pageId, [
                'title' => (string)$request->input('title'),
                'slug' => (string)$request->input('slug'),
                'meta_description' => (string)$request->input('meta_description'),
                'content' => (string)$request->input('content'),
                'is_published' => !empty($request->input('is_published')) ? 1 : 0,
            ]);

            $currentUser = current_user();
            AuditLogService::log(null, (int)($currentUser['id'] ?? 0), 'update_legal_page', 'legal_page', $pageId, [
                'title' => $request->input('title'),
                'slug' => $request->input('slug'),
            ]);

            return Response::success(['id' => $pageId], "Legal page successfully updated.");
        } catch (\Throwable $e) {
            return Response::error("Error updating legal page: " . $e->getMessage(), "ERROR", null, 400);
        }
    }

    public function superadminDeleteLegalPage(Request $request, string $id): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $pageId = (int)$id;
        $page = LegalPageService::getPageById($pageId);

        if (!$page) {
            return Response::error("Legal page not found.", "NOT_FOUND", null, 404);
        }

        if (in_array($page['slug'], ['privacy', 'terms', 'refund-policy', 'cookie-policy'])) {
            return Response::error("Cannot delete core system legal policy '{$page['title']}'. You may edit or unpublish it instead.", "ACTION_NOT_ALLOWED", null, 400);
        }

        LegalPageService::deletePage($pageId);

        $currentUser = current_user();
        AuditLogService::log(null, (int)($currentUser['id'] ?? 0), 'delete_legal_page', 'legal_page', $pageId, [
            'title' => $page['title'],
            'slug' => $page['slug'],
        ]);

        return Response::success(['id' => $pageId], "Legal page '{$page['title']}' permanently deleted.");
    }

    // ==========================================
    // SUPPORT TICKETS & HELP DESK CMS
    // ==========================================

    public function publicSupportChannels(Request $request): Response
    {
        $channels = SupportTicketService::getSupportChannels();
        return Response::success(['channels' => $channels]);
    }

    public function publicSubmitSupportTicket(Request $request): Response
    {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        if (!RateLimiterService::check('support_ticket', $ip, 5, 600)) {
            return Response::error("Too many support requests submitted. Please wait 10 minutes before submitting another ticket.", "RATE_LIMIT_EXCEEDED", null, 429);
        }

        try {
            $data = [
                'name' => (string)$request->input('name', ''),
                'email' => (string)$request->input('email', ''),
                'phone' => (string)$request->input('phone', ''),
                'category' => (string)$request->input('category', 'builder'),
                'subject' => (string)$request->input('subject', ''),
                'message' => (string)$request->input('message', ''),
            ];
            $ip = $_SERVER['REMOTE_ADDR'] ?? null;
            $ticket = SupportTicketService::createTicket($data, $ip);

            return Response::success(['ticket' => $ticket], "Your support ticket #{$ticket['ticket_num']} has been submitted successfully.");
        } catch (\Throwable $e) {
            return Response::error($e->getMessage(), "VALIDATION_FAILED", null, 400);
        }
    }

    public function superadminSupportTickets(Request $request): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $status = (string)$request->query('status', '');
        $search = (string)$request->query('search', '');

        $tickets = SupportTicketService::getAllTickets($status ?: null, $search ?: null);
        $stats = SupportTicketService::getTicketStats();
        $channels = SupportTicketService::getSupportChannels();

        return Response::success([
            'tickets' => $tickets,
            'stats' => $stats,
            'channels' => $channels,
        ]);
    }

    public function superadminUpdateSupportTicketStatus(Request $request, string $id): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $status = (string)$request->input('status', 'open');
        $notes = $request->input('admin_notes');

        try {
            SupportTicketService::updateTicketStatus((int)$id, $status, $notes !== null ? (string)$notes : null);
            return Response::success(['id' => (int)$id], "Ticket status updated to '{$status}'.");
        } catch (\Throwable $e) {
            return Response::error($e->getMessage(), "UPDATE_FAILED", null, 400);
        }
    }

    public function superadminDeleteSupportTicket(Request $request, string $id): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        SupportTicketService::deleteTicket((int)$id);
        return Response::success(['id' => (int)$id], "Support ticket deleted.");
    }

    public function superadminSaveSupportChannels(Request $request): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $channels = SupportTicketService::saveSupportChannels([
            'email' => (string)$request->input('email', ''),
            'phone' => (string)$request->input('phone', ''),
            'whatsapp' => (string)$request->input('whatsapp', ''),
            'hours' => (string)$request->input('hours', ''),
            'description' => (string)$request->input('description', ''),
        ]);

        return Response::success(['channels' => $channels], "Direct support contact channels successfully saved.");
    }

    public function superadminDocs(Request $request): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $sampleTenant = Database::fetchOne("SELECT id, name, slug FROM tenants WHERE status = 'active' LIMIT 1");
        $sampleFunnel = Database::fetchOne("SELECT id, name, slug FROM funnels WHERE status = 'published' LIMIT 1");
        if (!$sampleFunnel) {
            $sampleFunnel = Database::fetchOne("SELECT id, name, slug FROM funnels LIMIT 1");
        }

        $baseUrl = rtrim(url('/'), '/');

        return Response::success([
            'base_url' => $baseUrl,
            'sample_api_key' => $sampleTenant['api_key'] ?? 'qfn_live_abc123xyz789demo',
            'sample_funnel_slug' => $sampleFunnel['slug'] ?? 'sample-lead-quiz',
            'sample_funnel_name' => $sampleFunnel['name'] ?? 'Sample Quiz Funnel',
            'sample_funnel_id' => $sampleFunnel['id'] ?? 1,
            'endpoints' => [
                'quiz_manifest' => "{$baseUrl}/api/v1/quiz/{slug}",
                'submissions_api' => "{$baseUrl}/api/v1/funnels/{id}/submissions",
                'webhooks' => "{$baseUrl}/api/v1/webhooks/receive",
            ]
        ]);
    }

    public function superadminProfile(Request $request): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $currentUser = current_user();
        $user = Database::fetchOne("SELECT id, name, email, avatar_url, is_platform_admin, status, created_at FROM users WHERE id = ?", [(int)$currentUser['id']]);

        $auditCount = (int) Database::fetchColumn("SELECT COUNT(*) FROM audit_logs WHERE user_id = ?", [(int)$currentUser['id']]);

        return Response::success([
            'user' => $user ?: $currentUser,
            'audit_count' => $auditCount,
        ]);
    }

    public function superadminUpdateProfile(Request $request): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $userId = (int)current_user()['id'];
        $name = trim((string)$request->input('name', ''));
        $email = trim(strtolower((string)$request->input('email', '')));

        if (empty($name) || empty($email)) {
            return Response::error("Name and email are required fields.", "VALIDATION_FAILED", null, 400);
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return Response::error("Invalid email address format.", "VALIDATION_FAILED", null, 400);
        }

        $existing = Database::fetchOne("SELECT id FROM users WHERE email = ? AND id != ?", [$email, $userId]);
        if ($existing) {
            return Response::error("Email address '{$email}' is already in use by another account.", "EMAIL_TAKEN", null, 400);
        }

        $avatarUpdate = '';
        $params = [$name, $email];
        if ($request->input('remove_avatar')) {
            $avatarUpdate = ', avatar_url = NULL';
        } elseif ($request->has('avatar_url')) {
            $avatarUrl = trim((string)$request->input('avatar_url')) ?: null;
            $avatarUpdate = ', avatar_url = ?';
            $params[] = $avatarUrl;
        }
        $params[] = $userId;

        Database::execute("UPDATE users SET name = ?, email = ?{$avatarUpdate} WHERE id = ?", $params);

        $updatedUser = Database::fetchOne("SELECT id, name, email, avatar_url, is_platform_admin, status FROM users WHERE id = ?", [$userId]);
        Session::set('user', $updatedUser);

        AuditLogService::log(null, $userId, 'update_admin_profile', 'user', $userId, ['email' => $email, 'name' => $name]);

        return Response::success($updatedUser, "Profile details successfully updated.");
    }

    public function superadminUpdatePassword(Request $request): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $userId = (int)current_user()['id'];
        $currentPassword = (string)$request->input('current_password', '');
        $newPassword = (string)$request->input('new_password', '');
        $confirmPassword = (string)$request->input('confirm_password', '');

        if (empty($currentPassword) || empty($newPassword)) {
            return Response::error("All password fields are required.", "VALIDATION_FAILED", null, 400);
        }

        $user = Database::fetchOne("SELECT password_hash FROM users WHERE id = ?", [$userId]);
        if (!$user || !password_verify($currentPassword, $user['password_hash'])) {
            return Response::error("Current password is incorrect.", "INVALID_PASSWORD", null, 400);
        }

        if (strlen($newPassword) < 8) {
            return Response::error("New password must be at least 8 characters long.", "PASSWORD_TOO_SHORT", null, 400);
        }

        if ($newPassword !== $confirmPassword) {
            return Response::error("New password and password confirmation do not match.", "PASSWORDS_DO_NOT_MATCH", null, 400);
        }

        $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
        Database::execute("UPDATE users SET password_hash = ? WHERE id = ?", [$newHash, $userId]);

        AuditLogService::log(null, $userId, 'change_admin_password', 'user', $userId, []);

        return Response::success(null, "Password changed successfully.");
    }

    public function superadminLogs(Request $request): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $logs = Database::query(
            "SELECT al.*, u.name as user_name, u.email as user_email, t.name as tenant_name 
             FROM audit_logs al
             LEFT JOIN users u ON al.user_id = u.id
             LEFT JOIN tenants t ON al.tenant_id = t.id
             ORDER BY al.id DESC LIMIT 150"
        );

        return Response::success($logs);
    }

    // ==========================================
    // SUPER ADMIN EMAIL & SMTP MANAGEMENT
    // ==========================================

    public function superadminEmailSettings(Request $request): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $smtp = MailService::getSmtpSettings();
        // Hide actual password string for security, return mask indicator
        $smtpSafe = $smtp;
        $smtpSafe['has_password'] = !empty($smtp['password']);
        $smtpSafe['password'] = '';

        $templates = MailService::getTemplates();
        foreach ($templates as &$tpl) {
            if (!empty($tpl['available_tags']) && is_string($tpl['available_tags'])) {
                $tpl['available_tags'] = json_decode($tpl['available_tags'], true) ?: [];
            }
        }
        unset($tpl);

        $recentLogs = MailService::getRecentLogs(30);

        // Stats summary
        $totalSent = (int)(Database::fetchOne("SELECT COUNT(*) as c FROM email_logs WHERE status = 'sent'")['c'] ?? 0);
        $totalSimulated = (int)(Database::fetchOne("SELECT COUNT(*) as c FROM email_logs WHERE status = 'simulated'")['c'] ?? 0);
        $totalFailed = (int)(Database::fetchOne("SELECT COUNT(*) as c FROM email_logs WHERE status = 'failed'")['c'] ?? 0);

        return Response::success([
            'smtp' => $smtpSafe,
            'templates' => $templates,
            'logs' => $recentLogs,
            'stats' => [
                'total_sent' => $totalSent,
                'total_simulated' => $totalSimulated,
                'total_failed' => $totalFailed,
                'active_templates' => count($templates),
            ]
        ]);
    }

    public function superadminSaveSmtp(Request $request): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $admin = current_user();
        $input = [
            'enabled' => (bool)$request->input('enabled', false),
            'host' => trim((string)$request->input('host', '')),
            'port' => (int)$request->input('port', 587),
            'encryption' => (string)$request->input('encryption', 'tls'),
            'username' => trim((string)$request->input('username', '')),
            'password' => (string)$request->input('password', ''),
            'from_email' => trim((string)$request->input('from_email', '')),
            'from_name' => trim((string)$request->input('from_name', '')),
            'reply_to' => trim((string)$request->input('reply_to', '')),
        ];

        if (empty($input['host']) && $input['enabled']) {
            return Response::error("SMTP Host is required when enabling outbound email.", "VALIDATION_FAILED", null, 422);
        }

        MailService::saveSmtpSettings($input);
        AuditLogService::log(null, (int)$admin['id'], 'update_smtp_settings', 'platform_settings', null, [
            'enabled' => $input['enabled'],
            'host' => $input['host'],
            'port' => $input['port'],
            'encryption' => $input['encryption'],
            'from_email' => $input['from_email'],
        ]);

        return Response::success(null, "Global SMTP configuration saved successfully.");
    }

    public function superadminTestSmtp(Request $request): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $email = trim((string)$request->input('email', ''));
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return Response::error("Please provide a valid recipient email address for testing.", "VALIDATION_FAILED", null, 422);
        }

        $result = MailService::testSmtpConnection($email);
        if (!$result['success']) {
            return Response::error($result['message'], "SMTP_TEST_FAILED", null, 400);
        }

        return Response::success($result, $result['message']);
    }

    public function superadminSaveTemplate(Request $request): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $key = (string)$request->param('key');
        $admin = current_user();

        $data = [
            'name' => (string)$request->input('name', ''),
            'description' => (string)$request->input('description', ''),
            'subject' => (string)$request->input('subject', ''),
            'preheader' => (string)$request->input('preheader', ''),
            'body_html' => (string)$request->input('body_html', ''),
            'body_text' => (string)$request->input('body_text', ''),
            'is_active' => (int)$request->input('is_active', 1),
        ];

        if (empty($data['subject']) || empty($data['body_html'])) {
            return Response::error("Subject and HTML body content are required.", "VALIDATION_FAILED", null, 422);
        }

        $saved = MailService::saveTemplate($key, $data);
        if (!$saved) {
            return Response::error("Template '{$key}' not found.", "NOT_FOUND", null, 404);
        }

        AuditLogService::log(null, (int)$admin['id'], 'update_email_template', 'email_templates', null, [
            'template_key' => $key,
            'subject' => $data['subject']
        ]);

        return Response::success(null, "Email template '{$key}' updated successfully.");
    }

    public function superadminResetTemplate(Request $request): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $key = (string)$request->param('key');
        $reset = MailService::resetTemplateToDefault($key);
        if (!$reset) {
            return Response::error("Could not reset template '{$key}'.", "NOT_FOUND", null, 404);
        }

        return Response::success(null, "Template '{$key}' restored to system defaults.");
    }

    public function superadminPreviewTestEmail(Request $request): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $key = (string)$request->param('key');
        $email = trim((string)$request->input('email', ''));
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return Response::error("Please provide a valid recipient email address.", "VALIDATION_FAILED", null, 422);
        }

        $sampleTags = [
            'user_name' => 'John Doe',
            'user_email' => $email,
            'otp_code' => '749102',
            'otp_expiry_minutes' => 15,
            'tenant_name' => 'Acme Growth Labs',
            'workspace_slug' => 'acme-labs',
            'invoice_number' => 'INV-2026-0042',
            'plan_name' => 'Pro Unlimited',
            'amount' => '4,999.00',
            'currency_symbol' => '₹',
            'payment_method' => 'Razorpay / UPI',
            'billing_interval' => 'monthly',
            'paid_at' => date('Y-m-d H:i:s'),
            'due_date' => date('Y-m-d', strtotime('+7 days')),
            'suspension_reason' => 'Overdue subscription renewal past 7-day grace period',
        ];

        $result = MailService::sendTemplate($key, $email, 'Administrator Preview', $sampleTags);
        return Response::success($result, $result['message']);
    }

    public function superadminEmailLogs(Request $request): Response
    {
        if (!AuthorizationService::isPlatformAdmin()) {
            return Response::error("Super admin privilege required.", "FORBIDDEN", null, 403);
        }

        $limit = min(200, max(10, (int)$request->input('limit', 100)));
        $logs = MailService::getRecentLogs($limit);
        return Response::success($logs);
    }
}

